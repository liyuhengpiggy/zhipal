# 模型访问层独立工程
JDK17、Gradle8.7、SDK34。设置 ANDROID_HOME 或 local.properties 后运行：
gradle :model_client:testDebugUnitTest :model_client:assembleRelease

这是 Android Bitmap/HTTP 访问层，不含本地 Qwen 权重，也不注册助手服务。完整助手功能应接入外层 Android SDK。
