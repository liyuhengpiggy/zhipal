# 智能助手（B 助手）项目交接文档

> 生成时间：2026-10-24 23:51 GMT+8
> 用途：让另一个 agent 快速理解本项目背景、已完成的工作、遗留问题与构建方法。

---

## 一、需求背景（用户原始诉求）

用户提供一个基于 MobileAgent-Android 的移动端智能体项目源码（`b_agent_team_handoff.zip`），
希望改造成一个**移动端「预测下一步操作」辅助工具**，核心诉求：

1. 应用一直后台运行（前台服务保活）。
2. 后台挂起时屏幕上有**悬浮小图标**提示，可随时关闭。
3. 触发后调用视觉大模型，**预测用户下一步最想执行的操作**，弹窗询问确认，确认后执行。
4. API Key 硬编码进 APK（用户明确「忽略安全问题」）。

### 需求演进（重要）

- 最初设计：连点三下屏幕触发预测。
- **最终方案**：因华为 HarmonyOS 4.2 会强杀无障碍服务，三连击（依赖无障碍服务收触摸/点击事件）不可靠，
  最终改为**独立悬浮图标按钮触发**（用户确认选择此方案）。

---

## 二、用户环境（关键约束）

| 项目 | 值 |
|------|-----|
| 手机系统 | **HarmonyOS 4.2.0**（底层 Android 12，API 31） |
| 视觉模型服务 | **硅基流动 SiliconFlow**（`https://api.siliconflow.cn/v1`） |
| API Key | `sk-ylzzbvtwrcdduqlpqbjbbetuihukdprnuacokuasdbshojts` |
| 可用视觉模型 | **`Qwen/Qwen3-VL-32B-Instruct`**（已实测可用） |

⚠️ **HarmonyOS 关键限制**：
- `AccessibilityService.takeScreenshot()` 是 Android 14（API 34）API，HarmonyOS 4.2 上**不可用**，会崩溃。
  → 必须用 **MediaProjection 录屏截图**方案（`ScreenCaptureManager`）。
- 华为省电机制会**自动强杀无障碍服务**，导致悬浮图标消失、三连击失效。
  → 只能引导用户在系统「应用启动管理」里手动配置，代码层无法彻底阻止。

---

## 三、项目结构

源码根目录：`b_agent_team_handoff/b_agent_handoff/`

```
b_agent_handoff/
├── android_library/     # 核心库：AndroidAssistPort、Manager/Executor/Reflector、
│                        #   UiElementDetector、AccessibilityActions、ScreenCaptureManager 等
├── integration/         # BAssistEngine、Contracts（Observation/Suggestion/RecentEvent）
├── sample_app/          # ★ 实际打包成 APK 的模块（本次改造的主要对象）
│   └── src/main/java/com/bagent/sample/
│       ├── MainActivity.kt          # 启动引导页（权限引导 + 状态自检 + 启动悬浮图标）
│       ├── SampleAccessService.kt   # 无障碍服务（截图/预测/执行主流程 + 硬编码API）
│       ├── FloatingService.kt       # ★新增：独立悬浮图标前台服务（不依赖无障碍服务）
│       ├── FloatingIconManager.kt   # 悬浮图标管理（拖动/点击触发/长按关闭）
│       ├── ConfirmDialogActivity.kt # 预测结果确认弹窗
│       └── ErrorDialogActivity.kt   # ★新增：错误详情弹窗
├── tests/               # 测试与证据材料
├── upstream/            # 上游 MobileAgent-Android 参考
├── HANDOFF_MANIFEST.json / API_CONTRACT.md / APK_INTEGRATION.md 等交接文档
└── local.properties     # 指向本地 SDK 路径（见「构建环境」）
```

---

## 四、本次改造完成的工作

### 1. 触发方式（最终版：悬浮图标按钮）
- 新增 `FloatingService.kt`：独立前台服务持有悬浮图标，**不依赖无障碍服务**，即使无障碍服务被杀图标仍在。
- `FloatingIconManager.kt`：单击图标 → 触发预测；拖动图标；长按关闭。
- 单击图标时若无障碍服务未运行，弹窗引导用户重新开启。

### 2. 预测 + 确认 + 执行链路（复用原项目，微调）
- `SampleAccessService.predictNextStep()`：截图 → 读控件树 → 调模型 → 弹窗确认 → 执行。
- 复用 `AndroidAssistPort.observe()/suggest()/dispatchOnce()/reflect()`，未重写核心引擎。
- 目标语义固定为「预测用户下一步操作」，通过 `PREDICT_GOAL` 常量传入。

### 3. 硬编码 API 配置
- 位置：`SampleAccessService.kt` 的 `companion object`：
  ```kotlin
  const val API_ENDPOINT = "https://api.siliconflow.cn/v1"
  const val API_MODEL = "Qwen/Qwen3-VL-32B-Instruct"
  const val API_KEY = "sk-ylzzbvtwrcdduqlpqbjbbetuihukdprnuacokuasdbshojts"
  ```

### 4. 关键 Bug 修复（按时间顺序，重要）
| 问题 | 根因 | 修复 |
|------|------|------|
| 三连击无反应 | `TYPE_TOUCH_INTERACTION_START` 事件多数手机不派发 | 改用 `TYPE_VIEW_CLICKED`（后又被悬浮按钮方案替代） |
| `takeScreenshot` 崩溃 | Android 14 API，HarmonyOS 不可用 | 改用 MediaProjection（`ScreenCaptureManager`） |
| `API error 403` | 模型 `Qwen/Qwen2.5-VL-72B-Instruct` 已下线（`Model disabled`） | 换成 `Qwen/Qwen3-VL-32B-Instruct`（已实测） |
| 图标消失+无反应 | 华为强杀无障碍服务 | 悬浮图标独立成前台服务 |
| `page_changed_during_capture` | windowId 在 HarmonyOS 上不稳定（点悬浮窗/截图都会变） | 身份判断移除 windowId，只用 packageName |

### 5. 本次对核心库的修改（`android_library`）
`AndroidAssistPort.kt` 两处改动：
1. `observe()`：移除「截图前后控件树必须完全一致」的严格校验，只要求 `identity()`（包名）不变。
2. `identity()`：`windowId` 固定返回 0，让身份判断只依赖 packageName。

---

## 五、构建环境（本机已就绪）

工具都在 `C:/Users/20647/WorkBuddy/2026-10-24-21-47-45/tools/` 下：

| 工具 | 路径 |
|------|------|
| JDK 17 | `tools/jdk-17.0.2/` |
| Android SDK | `tools/sdk/`（platforms/android-34 + build-tools/34.0.0 + platform-tools） |
| Gradle 8.7 | `tools/gradle-8.7/`（**不要用 `gradlew`**，其 wrapper 下载 services.gradle.org 会超时） |

`local.properties`（源码根目录）内容：
```
sdk.dir=C\:\\Users\\20647\\WorkBuddy\\2026-10-24-21-47-45\\tools\\sdk
```

### 构建命令
```bash
cd "C:/Users/20647/WorkBuddy/2026-10-24-21-47-45/b_agent_team_handoff/b_agent_handoff"
export JAVA_HOME="C:/Users/20647/WorkBuddy/2026-10-24-21-47-45/tools/jdk-17.0.2"
export ANDROID_HOME="C:/Users/20647/WorkBuddy/2026-10-24-21-47-45/tools/sdk"
export PATH="$JAVA_HOME/bin:$PATH"
"C:/Users/20647/WorkBuddy/2026-10-24-21-47-45/tools/gradle-8.7/bin/gradle.bat" :sample_app:assembleDebug --no-daemon
```

产物：`sample_app/build/outputs/apk/debug/sample_app-debug.apk`

### 交付物
- 成品 APK 已复制到桌面：`C:/Users/20647/Desktop/智能助手.apk`（约 5.7MB，debug 签名）
- 包名 `com.bagent.sample`，应用名「智能助手」

---

## 六、当前状态与遗留问题

### 已完成
- [x] 悬浮图标独立前台服务（不易被杀）
- [x] 悬浮图标按钮触发预测 + 确认弹窗 + 执行
- [x] MediaProjection 截图（兼容 HarmonyOS 4.2）
- [x] 硬编码 SiliconFlow + Qwen3-VL-32B 模型（已实测可用）
- [x] 错误详情弹窗（方便定位问题）
- [x] `page_changed_during_capture` 修复（移除 windowId 依赖）

### 待验证 / 遗留
- [ ] **端到端验证**：用户尚未反馈「预测弹窗是否成功弹出 + 执行是否成功」。这是当前最大的不确定点。
- [ ] 华为省电杀后台：即使悬浮图标独立，华为仍可能杀前台服务，需用户手动配置「应用启动管理」。
- [ ] debug 签名：正式使用需用户自己的签名重签。
- [ ] 模型可选：`Qwen/Qwen3-VL-8B-Instruct` 更快更省（精度略降），可作为备选。

### 给接手 agent 的下一步建议
1. 先等用户反馈「点悬浮图标是否弹出预测弹窗」。
2. 若弹窗出现但内容不合理 → 检查 prompt（`AndroidAssistPort.suggest` 里的 Manager/Executor prompt）。
3. 若执行失败 → 检查 `dispatchOnce` 的坐标匹配（`target()` 要求中心点坐标精确匹配）。
4. 若华为仍杀服务 → 只能加强用户引导（无法从代码根治）。

---

## 七、技术要点速查

- **截图**：`SampleAccessService.screenshot()` → `ScreenCaptureManager.capture()`（MediaProjection + ImageReader）。
- **预测**：`AndroidAssistPort.suggest(goal, history, screen)` 内部走 Manager（规划）→ Executor（选单个点击）→ 返回 `Suggestion`。
- **执行**：`AndroidAssistPort.dispatchOnce()` → `AccessibilityActions.performTap()`（无障碍手势真实点击）。
- **线程**：所有 `observe/suggest/dispatchOnce` 都要求主线程（`assertMain`），`scope = Dispatchers.Main.immediate`。
- **资源释放**：`Observation` 用 token 管理 frame（bitmap），用完必须 `release()`，否则内存泄漏。
