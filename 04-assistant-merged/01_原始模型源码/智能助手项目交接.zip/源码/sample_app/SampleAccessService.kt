package com.bagent.sample

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.bagent.android.AndroidAssistPort
import com.bagent.integration.Observation
import com.bagent.integration.RecentEvent
import com.bagent.integration.Suggestion
import com.mobileagent.app.api.ApiConfig
import com.mobileagent.app.api.OpenAiCompatibleClient
import com.mobileagent.app.api.VlmApiClient
import com.mobileagent.app.controller.ScreenCaptureManager
import kotlinx.coroutines.*

/**
 * B 助手无障碍服务：
 * 1. 前台服务常驻后台（通知栏小图标）。
 * 2. 悬浮小图标提示运行中，可拖动、可长按关闭。
 * 3. 连续点三下屏幕 -> 预测下一步操作 -> 弹窗确认 -> 执行一步。
 */
class SampleAccessService : AccessibilityService() {
    companion object {
        var instance: SampleAccessService? = null
            private set
        const val CHANNEL_ID = "b_assist_channel"
        const val NOTIFICATION_ID = 1001

        // 硬编码 SiliconFlow 配置
        const val API_ENDPOINT = "https://api.siliconflow.cn/v1"
        const val API_MODEL = "Qwen/Qwen3-VL-32B-Instruct"
        const val API_KEY = "sk-ylzzbvtwrcdduqlpqbjbbetuihukdprnuacokuasdbshojts"

        private const val PREDICT_GOAL = "根据用户最近的操作历史和当前屏幕内容，预测用户最可能想执行的下一步操作。"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val config = ApiConfig(
        provider = "openai",
        endpoint = API_ENDPOINT,
        apiKey = API_KEY,
        model = API_MODEL,
        coordType = "absolute",
        maxSteps = 1
    )
    private val apiClient: VlmApiClient = OpenAiCompatibleClient(config)
    private val port: AndroidAssistPort by lazy { AndroidAssistPort(this, ::screenshot, apiClient, scope) }
    private var screenCapture: ScreenCaptureManager? = null

    // 三连击检测状态
    private val touchTimes = ArrayDeque<Long>()
    private var pendingSuggestion: Suggestion? = null
    private var pendingScreen: Observation? = null
    private var predicting = false

    // 近期事件历史（供预测使用）
    private val recentEvents = ArrayDeque<RecentEvent>()

    override fun onServiceConnected() {
        instance = this
        getSharedPreferences("access_status", Context.MODE_PRIVATE).edit().putBoolean("was_connected", true).apply()
        startForegroundService()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START -> onTap()
            AccessibilityEvent.TYPE_VIEW_CLICKED -> { onTap(); recordClick(event) }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> recordPage(event)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> recordOther(event)
        }
    }

    private fun onTap() {
        val now = SystemClock.elapsedRealtime()
        // 去重：同一物理点击可能同时触发 touch + click 两个事件，间隔 <80ms 视为同一次
        if (touchTimes.isNotEmpty() && now - touchTimes.last() < 80) return
        touchTimes.addLast(now)
        // 只保留 1000ms 内的点击
        while (touchTimes.isNotEmpty() && now - touchTimes.first() > 1000) touchTimes.removeFirst()
        if (touchTimes.size >= 3 && !predicting) {
            touchTimes.clear()
            predictNextStep()
        }
    }

    private fun recordClick(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        val source = event.source
        val control = try { source?.let { "${event.packageName}|${it.viewIdResourceName}|${it.text}|${it.contentDescription}" }.orEmpty() } finally { source?.recycle() }
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.CLICK, page, control))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    private fun recordPage(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.PAGE, page))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    private fun recordOther(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.OTHER, page))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    /**
     * 三连击触发：截图 -> 模型预测下一步 -> 弹窗确认。
     */
    fun predictNextStep() {
        if (predicting) return
        predicting = true
        scope.launch {
            var screen: Observation? = null
            try {
                if (screenCapture == null) {
                    showErrorDialog("屏幕截图尚未初始化！\n\n请先打开「智能助手」App，点击第 2 步「授权屏幕截图（录屏）」，在系统弹窗里点「允许/开始」。\n\n授权后再连点三下屏幕。")
                    return@launch
                }
                val history = recentEvents.toList()
                screen = port.observe()
                val suggestion = port.suggest(PREDICT_GOAL, history, screen)
                pendingSuggestion = suggestion
                pendingScreen = screen
                screen = null // 所有权转交，确认或取消时释放
                showConfirmDialog(suggestion.description)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                pendingSuggestion = null
                pendingScreen?.let { port.release(it) }
                pendingScreen = null
                showErrorDialog("预测失败：\n${e.message ?: "未知错误"}\n\n（请把这段文字发给开发者）")
            } finally {
                screen?.let { port.release(it) }
                predicting = false
            }
        }
    }

    private fun showConfirmDialog(description: String) {
        val intent = Intent(this, ConfirmDialogActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtra(ConfirmDialogActivity.EXTRA_DESCRIPTION, description)
        try { startActivity(intent) } catch (_: Exception) {}
    }

    private fun showErrorDialog(message: String) {
        val intent = Intent(this, ErrorDialogActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtra(ErrorDialogActivity.EXTRA_MESSAGE, message)
        try { startActivity(intent) } catch (_: Exception) {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** 用户点了"执行"。 */
    fun onUserConfirmNextStep() {
        val suggestion = pendingSuggestion
        val screen = pendingScreen
        pendingSuggestion = null
        pendingScreen = null
        if (suggestion == null || screen == null) return
        scope.launch {
            var fresh: Observation? = null
            var after: Observation? = null
            var dispatched = false
            try {
                fresh = port.observe()
                if (fresh.fingerprint != screen.fingerprint || fresh.packageName != screen.packageName || fresh.windowId != screen.windowId) {
                    android.widget.Toast.makeText(this@SampleAccessService, "页面已变化，取消执行", android.widget.Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val completion = port.dispatchOnce(fresh, suggestion)
                dispatched = true
                check(completion.await()) { "操作被拒绝" }
                delay(800)
                after = port.observe()
                port.reflect(fresh, after, suggestion, PREDICT_GOAL)
                android.widget.Toast.makeText(this@SampleAccessService, "已执行：${suggestion.description}", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (dispatched) {
                    android.widget.Toast.makeText(this@SampleAccessService, "已点击，结果未知", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    showErrorDialog("执行失败：\n${e.message ?: "未知错误"}\n\n（请把这段文字发给开发者）")
                }
            } finally {
                fresh?.let { port.release(it) }
                after?.let { port.release(it) }
                port.release(screen)
            }
        }
    }

    /** 用户点了"取消"。 */
    fun onUserRejectNextStep() {
        val screen = pendingScreen
        pendingSuggestion = null
        pendingScreen = null
        screen?.let { port.release(it) }
    }

    /** 录屏授权回调后初始化截图。 */
    fun initScreenCapture(resultCode: Int, data: Intent) {
        try {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mpManager.getMediaProjection(resultCode, data)
            screenCapture?.release()
            screenCapture = ScreenCaptureManager(this).also { it.initialize(projection) }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "截图初始化失败：${e.message}", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private suspend fun screenshot(): Bitmap? {
        val capture = screenCapture ?: return null
        return capture.capture()
    }

    /** 供 MainActivity 查询截图是否已就绪。 */
    fun hasScreenCapture(): Boolean = screenCapture != null

    private fun startForegroundService() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "智能助手后台服务", NotificationManager.IMPORTANCE_LOW))
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)
        val built = notification
            .setContentTitle("智能助手正在运行")
            .setContentText("连点三下屏幕预测下一步操作")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, built, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, built)
        }
    }

    override fun onInterrupt() {
        pendingScreen?.let { port.release(it) }
        pendingScreen = null
        pendingSuggestion = null
    }

    override fun onDestroy() {
        screenCapture?.release()
        screenCapture = null
        scope.cancel()
        instance = null
        super.onDestroy()
    }
}
