package com.bagent.sample

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

/**
 * 启动引导页：引导用户开启无障碍服务、录屏授权、悬浮窗权限和通知权限。
 * 配置已内置（SiliconFlow），无需手动填写。
 */
class MainActivity : Activity() {
    companion object {
        const val REQUEST_SCREEN_CAPTURE = 2001
        const val REQUEST_NOTIFICATION = 100
    }

    private lateinit var projectionManager: MediaProjectionManager
    private var statusText: TextView? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 32) }
        layout.addView(TextView(this).apply {
            text = "智能助手"
            textSize = 26f
            setTextColor(0xFF111111.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "点击屏幕边缘的悬浮图标，自动预测并帮你完成下一步操作。\n\n使用前请依次开启以下权限："
            textSize = 16f
            setTextColor(0xFF444444.toInt())
            setPadding(0, 16, 0, 16)
        })

        fun button(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply { this.text = text; setOnClickListener { action() } })
        }
        button("1. 开启无障碍服务") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. 授权屏幕截图（录屏）") {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
        }
        button("3. 开启悬浮窗权限") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show()
            }
        }
        button("4. 开启通知权限（Android 13+）") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATION)
            } else {
                Toast.makeText(this, "无需额外通知权限", Toast.LENGTH_SHORT).show()
            }
        }
        button("5. 启动悬浮图标") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限（第 3 步）", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this, FloatingService::class.java))
                Toast.makeText(this, "悬浮图标已启动，点击图标即可预测下一步", Toast.LENGTH_SHORT).show()
            }
        }

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, 32, 0, 8)
        }
        layout.addView(statusText)
        layout.addView(Button(this).apply {
            text = "刷新状态"
            setOnClickListener { refreshStatus() }
        })

        layout.addView(TextView(this).apply {
            text = "\n提示：华为/鸿蒙手机请务必在「设置→应用→启动管理」中，把智能助手设为「手动管理」，并打开「自启动」「关联启动」「后台活动」三个开关，否则系统会杀掉无障碍服务，导致三连击失效。"
            textSize = 13f
            setTextColor(0xFFCC0000.toInt())
        })
        setContentView(layout)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val accessOn = isAccessibilityOn()
        val serviceRunning = SampleAccessService.instance != null
        val captureReady = SampleAccessService.instance?.hasScreenCapture() == true
        statusText?.text = buildString {
            append("【当前状态】\n")
            append("无障碍服务：${if (accessOn) "已开启" else "未开启"}\n")
            append("后台服务：${if (serviceRunning) "运行中" else "未运行"}\n")
            append("录屏截图：${if (captureReady) "已就绪" else "未授权"}\n\n")
            append(if (accessOn && serviceRunning && captureReady) "✅ 一切就绪，可点击悬浮图标预测下一步" else "⚠️ 请先完成上面未开启的步骤")
        }
    }

    private fun isAccessibilityOn(): Boolean {
        val prefs = getSharedPreferences("access_status", Context.MODE_PRIVATE)
        // 简单判断：服务实例存在即认为开启（更准确的判断需要遍历系统设置，这里用实例状态）
        return SampleAccessService.instance != null || prefs.getBoolean("was_connected", false)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                SampleAccessService.instance?.initScreenCapture(resultCode, data)
                Toast.makeText(this, "录屏授权成功", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "录屏授权被拒绝，无法截图", Toast.LENGTH_SHORT).show()
            }
            refreshStatus()
        }
    }
}
