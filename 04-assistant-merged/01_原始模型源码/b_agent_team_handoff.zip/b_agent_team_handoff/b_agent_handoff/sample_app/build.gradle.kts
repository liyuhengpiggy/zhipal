plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.bagent.sample"
 compileSdk = 34
 defaultConfig { applicationId = "com.bagent.sample"; minSdk = 30; targetSdk = 34; versionCode = 1; versionName = "1.0"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 implementation(project(":android_library"))
 androidTestImplementation("androidx.test:runner:1.5.2")
 androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
 androidTestImplementation("junit:junit:4.13.2")
}
