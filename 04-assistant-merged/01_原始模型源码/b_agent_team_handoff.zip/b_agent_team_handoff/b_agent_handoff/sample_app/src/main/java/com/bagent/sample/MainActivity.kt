package com.bagent.sample

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.widget.*
import com.mobileagent.app.api.ApiConfig

class MainActivity : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        fun input(hint: String) = EditText(this).also { it.hint = hint; layout.addView(it) }
        layout.addView(TextView(this).apply { text = "B 模块集成测试。填写自己的视觉模型服务后保存；API 密钥仅保存在本进程内存。主 APK 接入无需此 Activity。" })
        val endpoint = input("OpenAI 兼容地址，例如 https://host/v1")
        val model = input("视觉模型名称")
        val key = input("API Key").apply { inputType = 129 }
        fun button(text: String, action: () -> Unit) { layout.addView(Button(this).apply { this.text = text; setOnClickListener { action() } }) }
        button("保存模型配置") {
            if (!endpoint.text.toString().startsWith("https://") || model.text.isBlank()) { Toast.makeText(this, "请填写 HTTPS 地址和视觉模型名", Toast.LENGTH_SHORT).show() }
            else { DemoState.config = ApiConfig(endpoint = endpoint.text.toString(), model = model.text.toString(), apiKey = key.text.toString(), maxSteps = 1); SampleAccessService.instance?.configure(); Toast.makeText(this, "配置已载入内存", Toast.LENGTH_SHORT).show() }
        }
        button("打开无障碍设置") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("进入真实测试页面") { startActivity(Intent(this, ScenarioActivity::class.java)) }
        setContentView(layout)
    }
}
