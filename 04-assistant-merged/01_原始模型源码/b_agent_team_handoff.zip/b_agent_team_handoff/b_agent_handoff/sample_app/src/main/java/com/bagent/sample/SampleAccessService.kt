package com.bagent.sample

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.bagent.android.BAssist
import com.bagent.integration.*
import com.mobileagent.app.api.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object DemoState : AssistListener {
    var config = ApiConfig()
    var prompt: AssistPrompt? = null
    val events = mutableListOf<AssistEvent>()
    var clicks = 0
    var apiCalls = 0
    var screenshotCalls = 0
    override fun onPrompt(prompt: AssistPrompt) { this.prompt = prompt; android.util.Log.i("BAgentDemo", "PROMPT ${prompt.promptId}: ${prompt.text}") }
    override fun onEvent(event: AssistEvent) { events.add(event); if (events.size > 100) events.removeAt(0); android.util.Log.i("BAgentDemo", "${event.type}: ${event.detail}") }
}
class SampleAccessService : AccessibilityService() {
    companion object { var instance: SampleAccessService? = null; private set }
    var assist: BAssist? = null
        private set
    override fun onServiceConnected() { instance = this; configure() }
    fun configure(api: VlmApiClient = OpenAiCompatibleClient(DemoState.config)) {
        assist?.close()
        val tracked = object : VlmApiClient {
            override suspend fun predictWithImages(systemPrompt: String?, textPrompt: String, images: List<Bitmap>): Result<String> {
                DemoState.apiCalls++; return api.predictWithImages(systemPrompt, textPrompt, images)
            }
        }
        assist = BAssist(this, ::screenshot, DemoState.config, DemoState, tracked).also { it.startObserving() }
    }
    suspend fun screenshot(): Bitmap? = suspendCancellableCoroutine { continuation ->
        DemoState.screenshotCalls++
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hardware = result.hardwareBuffer
                val wrapped = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                val bitmap = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                wrapped?.recycle(); hardware.close()
                if (continuation.isActive) continuation.resume(bitmap) else bitmap?.recycle()
            }
            override fun onFailure(errorCode: Int) { if (continuation.isActive) continuation.resume(null) }
        })
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { if (event != null) assist?.onAccessibilityEvent(event) }
    override fun onInterrupt() { assist?.cancelAssist() }
    override fun onDestroy() { assist?.close(); assist = null; instance = null; super.onDestroy() }
}
