package com.bagent.sample

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.util.UUID

/** Test fixture only: controls are real Android views. Dead clicks never change the page. */
class ScenarioActivity : Activity() {
    private var page = 0
    override fun onCreate(state: Bundle?) { super.onCreate(state); render() }
    private fun render() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 24) }
        layout.addView(TextView(this).apply { text = if (page == 0) "联系人" else "女儿的联系方式"; textSize = 24f })
        fun button(text: String, id: Int = 0, action: () -> Unit) { layout.addView(Button(this).apply { this.text = text; if (id != 0) this.id = id; setOnClickListener { action() } }) }
        if (page == 0) {
            button("暂不可用的按钮", R.id.dead_button) { /* Deliberately no navigation or UI change. */ }
            button("女儿", R.id.daughter_button) { DemoState.clicks++; page = 1; render() }
        } else {
            button("视频通话", R.id.video_button) { DemoState.clicks++; Toast.makeText(this, "测试视频页面", Toast.LENGTH_SHORT).show() }
            button("回到联系人") { page = 0; render() }
        }
        // Instrumentation uses a normal contact screen; debug voice controls stay on the manual demo.
        if (intent.getBooleanExtra("fixture_only", false)) { setContentView(layout); return }
        val voice = EditText(this).apply { hint = "主 APK 已完成的 B 语音转写，例如：我想和女儿视频" }
        layout.addView(voice)
        button("模拟 B 主动求助") { SampleAccessService.instance?.assist?.onBHelpRequested(UUID.randomUUID().toString()); showPrompt() }
        button("提交 B 转写文字") {
            val assist = SampleAccessService.instance?.assist
            val p = assist?.currentPrompt
            if (p != null) assist.onBSpeechResult(p.taskId, p.promptId, "B", voice.text.toString())
            voice.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(voice.windowToken, 0)
            window.decorView.postDelayed({ showPrompt() }, 1500)
        }
        button("查看最新帮助问题") { showPrompt() }
        button("模拟 A 开始") { SampleAccessService.instance?.assist?.onATaskStarted() }
        button("模拟 A 结束") { SampleAccessService.instance?.assist?.onATaskFinished() }
        setContentView(layout)
    }
    private fun showPrompt() { Toast.makeText(this, SampleAccessService.instance?.assist?.currentPrompt?.text ?: "当前无待确认问题，请查看 logcat BAgentDemo", Toast.LENGTH_LONG).show() }
}
