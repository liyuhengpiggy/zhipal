package com.bagent.sample

import android.app.UiAutomation
import androidx.test.uiautomator.Configurator
import android.content.Intent
import android.graphics.Bitmap
import android.os.SystemClock
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.bagent.integration.*
import com.mobileagent.app.api.*
import com.mobileagent.app.controller.UiElementDetector
import org.junit.*
import org.junit.Assert.*
import java.io.File

/** Real Android views/gestures throughout. Only guard cases explicitly use a mock model. */
class DeviceAcceptanceTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val device = run {
        Configurator.getInstance().uiAutomationFlags = UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES
        UiDevice.getInstance(instrumentation)
    }
    private val context get() = instrumentation.targetContext
    private val evidence get() = File(context.getExternalFilesDir(null), "acceptance").also { it.mkdirs() }
    private fun <T> main(block: () -> T): T {
        var value: Any? = null; var failure: Throwable? = null
        instrumentation.runOnMainSync { try { value = block() } catch(t:Throwable) { failure=t } }
        failure?.let { throw it }
        @Suppress("UNCHECKED_CAST") return value as T
    }
    private fun await(label:String, timeout:Long=20000, condition:()->Boolean) {
        val start=SystemClock.elapsedRealtime()
        while(SystemClock.elapsedRealtime()-start<timeout) { if(condition())return; SystemClock.sleep(150) }
        fail("Timed out: $label; events=${main { DemoState.events.toList() }}")
    }
    private fun service() = SampleAccessService.instance ?: error("Enable sample AccessibilityService first")
    @Before fun prepare() {
        device.executeShellCommand("settings put secure enabled_accessibility_services ''")
        device.executeShellCommand("settings put secure enabled_accessibility_services com.bagent.sample/.SampleAccessService")
        device.executeShellCommand("settings put secure accessibility_enabled 1")
        await("accessibility service connected") { main { SampleAccessService.instance != null } }
        main { service().assist?.cancelAssist(); DemoState.clicks=0; DemoState.apiCalls=0; DemoState.events.clear(); DemoState.prompt=null }
        context.startActivity(Intent(context,ScenarioActivity::class.java).putExtra("fixture_only",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        await("fixture contact page") { device.hasObject(By.res("com.bagent.sample","daughter_button")) }
        device.waitForIdle();SystemClock.sleep(1100)
    }
    @After fun saveEvents() {
        File(evidence,"${testName.methodName}-events.txt").writeText(main { DemoState.events.joinToString("\n") })
        device.takeScreenshot(File(evidence,"${testName.methodName}-screen.png"))
        main { SampleAccessService.instance?.assist?.cancelAssist() }
    }
    @get:Rule val testName=org.junit.rules.TestName()
    private fun goal(): AssistPrompt {
        main { service().assist!!.onBHelpRequested("device-${testName.methodName}") }
        val q=main { service().assist!!.currentPrompt!! }
        main { service().assist!!.onBSpeechResult(q.taskId,q.promptId,"B","我想和女儿视频") }
        await("single-action proposal",180000) {
            main { service().assist!!.currentPrompt?.kind == PromptKind.ACTION || DemoState.events.any { it.type=="analysis_failed" } }
        }
        val result=main { service().assist!!.currentPrompt }
        assertEquals("No valid model proposal; ${main { DemoState.events.toList() }}",PromptKind.ACTION,result?.kind)
        return result!!
    }
    private fun speech(q:AssistPrompt,text:String) = main { service().assist!!.onBSpeechResult(q.taskId,q.promptId,"B",text) }
    private fun mockModel() {
        // Explicit test double for guard tests, computed from current real Android tree, never used by realModel test.
        main { service().configure(object:VlmApiClient {
            override suspend fun predictWithImages(systemPrompt:String?,textPrompt:String,images:List<Bitmap>):Result<String> {
                val target=UiElementDetector.detectElements(service()).first { it.viewId.endsWith("daughter_button") }
                return Result.success("### Thought ###\nTest double for guard only.\n### Plan ###\nOpen contact.\n### Current subgoal ###\nOpen contact.\n### Action ###\n{\"action\":\"click\",\"coordinate\":[${target.bounds.centerX()},${target.bounds.centerY()}]}\n### Description ###\n点击女儿。")
            }
        }) }
    }
    @Test fun automaticDifficultyFromThreeActualClicks() {
        mockModel()
        repeat(3) { device.findObject(By.res("com.bagent.sample","dead_button")).click();SystemClock.sleep(500) }
        await("real event difficulty detection") { main { DemoState.events.any { it.type=="difficulty_suspected" } } }
        assertEquals(PromptKind.GOAL,main { service().assist!!.currentPrompt?.kind })
        assertEquals(0,main { DemoState.clicks });assertEquals(0,main { DemoState.apiCalls })
    }
    @Test fun realModelScreenshotConfirmationOneGestureAndStop() {
        val args=InstrumentationRegistry.getArguments()
        val endpoint=args.getString("endpoint") ?: error("Real model test requires endpoint argument")
        val model=args.getString("model") ?: "qwen3-vl-2b"
        var n=0
        main {
            DemoState.config=ApiConfig(endpoint=endpoint,model=model,apiKey="local-test-only")
            val real=OpenAiCompatibleClient(DemoState.config)
            service().configure(object:VlmApiClient {
                override suspend fun predictWithImages(systemPrompt:String?,textPrompt:String,images:List<Bitmap>):Result<String> {
                    val call=++n
                    File(evidence,"real-$call-prompt.txt").writeText(textPrompt)
                    images.forEachIndexed { i,b -> File(evidence,"real-$call-image-$i.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG,100,it) } }
                    val response=real.predictWithImages(systemPrompt,textPrompt,images)
                    File(evidence,"real-$call-response.txt").writeText(response.fold({it},{"ERROR: $it"}))
                    return response
                }
            })
        }
        val q=goal();File(evidence,"real-proposal.txt").writeText(q.toString())
        assertEquals("Model should select the actual contact for the stated goal", "点击“女儿”。要我只执行这一步吗？请说“对”确认。",q.text)
        assertTrue(main { DemoState.apiCalls>=2 });assertTrue(main { DemoState.screenshotCalls>0 })
        speech(q,"对");speech(q,"对");speech(q,"对")
        await("physical contact click",15000) { main { DemoState.clicks==1 } }
        await("real reflection and stop",180000) { main { DemoState.events.any { it.type=="stopped" && it.detail=="single_step_complete" } } }
        assertTrue(device.hasObject(By.res("com.bagent.sample","video_button")))
        assertEquals(1,main { DemoState.events.count { it.type=="action_dispatched" } })
        assertTrue(main { DemoState.events.any { it.type=="execution_result" && it.detail.startsWith("A:") } })
        SystemClock.sleep(2500);assertEquals(1,main { DemoState.clicks });assertNull(main { service().assist!!.currentPrompt })
    }
    @Test fun refusalWithRealScreenAndMockModelNeverClicks() {
        mockModel();val q=goal();speech(q,"不用了");SystemClock.sleep(1500)
        assertEquals(0,main { DemoState.clicks });assertNull(main { service().assist!!.currentPrompt })
    }
    @Test fun changedRealPageInvalidatesMockProposal() {
        mockModel();val q=goal()
        device.findObject(By.res("com.bagent.sample","daughter_button")).click()
        await("external page navigation") { device.hasObject(By.res("com.bagent.sample","video_button")) }
        SystemClock.sleep(800);speech(q,"对")
        await("stale page rejected") { main { DemoState.events.any { it.detail=="stale_page" } } }
        assertEquals(1,main { DemoState.clicks });assertEquals(0,main { DemoState.events.count { it.type=="action_dispatched" } })
    }
    @Test fun aPreemptsPendingMockProposalOnRealDevice() {
        mockModel();val q=goal();main { service().assist!!.onATaskStarted() };speech(q,"对")
        main { service().assist!!.onATaskFinished() };speech(q,"对");SystemClock.sleep(1500)
        assertEquals(0,main { DemoState.clicks });assertEquals(0,main { DemoState.events.count { it.type=="action_dispatched" } })
    }
}
