param(
 [string]$Endpoint = "",
 [string]$Model = "qwen3-vl-2b",
 [string]$Gradle = "",
 [switch]$GuardsOnly,
 [int]$ReversePort = 0
)
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$adb = Join-Path $env:ANDROID_HOME "platform-tools/adb.exe"
if (!(Test-Path -LiteralPath $adb)) { throw "Set ANDROID_HOME to installed SDK" }
if (!$GuardsOnly -and !$Endpoint) { throw "Real vision acceptance requires -Endpoint; use -GuardsOnly for explicit mock guard cases" }
Push-Location $projectRoot
try {
 if (!$Gradle) { $Gradle = Join-Path $projectRoot "gradlew.bat" }
 & $Gradle :integration:test :sample_app:assembleDebug :sample_app:assembleDebugAndroidTest --console=plain
 if ($LASTEXITCODE) { throw "Gradle build failed" }
 & $adb install -r (Join-Path $projectRoot "sample_app/build/outputs/apk/debug/sample_app-debug.apk")
 if ($LASTEXITCODE) { throw "APK install failed" }
 & $adb install -r (Join-Path $projectRoot "sample_app/build/outputs/apk/androidTest/debug/sample_app-debug-androidTest.apk")
 if ($LASTEXITCODE) { throw "Test APK install failed" }
 if ($ReversePort -gt 0) { & $adb reverse "tcp:$ReversePort" "tcp:$ReversePort" }
 $testClass = "com.bagent.sample.DeviceAcceptanceTest"
 if ($GuardsOnly) {
  $testClass = (("automaticDifficultyFromThreeActualClicks","refusalWithRealScreenAndMockModelNeverClicks","changedRealPageInvalidatesMockProposal","aPreemptsPendingMockProposalOnRealDevice") | ForEach-Object { "com.bagent.sample.DeviceAcceptanceTest#$_" }) -join ","
 }
 $arguments = @("shell","am","instrument","-w","-r","-e","class",$testClass)
 if (!$GuardsOnly) { $arguments += @("-e","endpoint",$Endpoint,"-e","model",$Model) }
 $arguments += "com.bagent.sample.test/androidx.test.runner.AndroidJUnitRunner"
 $result = & $adb @arguments 2>&1
 $result | Set-Content -LiteralPath (Join-Path $PSScriptRoot "last-device-run.log") -Encoding UTF8
 $result
 if (($result -join "`n") -notmatch 'OK \(\d+ tests?\)') { throw "Instrumentation acceptance failed; inspect last-device-run.log" }
 $destination=Join-Path $PSScriptRoot "last-device-evidence"
 New-Item -ItemType Directory -Path $destination -Force | Out-Null
 & $adb pull /sdcard/Android/data/com.bagent.sample/files/acceptance $destination
} finally { Pop-Location }
