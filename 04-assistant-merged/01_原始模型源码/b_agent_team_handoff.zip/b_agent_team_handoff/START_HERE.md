# 队友接手入口

日期：2026-10-24（Asia/Shanghai）。本包用于继续开发 ESP32-S3 智能眼镜 + Android 老年人助手的 App 与云端。

## 先看哪些文件

1. 本文件：整体范围、分工与验收顺序。
2. b_agent_handoff/APK_INTEGRATION.md：主 APK 的真实接入代码及依赖。
3. b_agent_handoff/API_CONTRACT.md：B 的确认绑定、超时、取消、回调与 A/B 隔离。
4. CLOUD_HANDOFF.md：现有模型 HTTP 契约、部署选择及待完成项。
5. b_agent_handoff/TEST_REPORT.md：已通过项、真实截图/模型证据、失败记录和未验收边界。
6. ORIGINAL_REQUIREMENTS.md：原始任务要求。

## 包内内容

- b_agent_handoff/：完整 B 模块源码、Gradle wrapper、Android Library、integration、示例 App、单元及设备测试、构建产物、10个运行依赖JAR、许可证、来源与修改补丁、全部归档测试证据。
- upstream/MobileAgent-Android/：上游精确 commit 的原始跟踪文件快照；非本机修改工作区，不含.git。构建修复补丁在 b_agent_handoff/upstream_patches/，最新端侧native路径仍未验收；不包含未拉取子模块内容。
- reference-artifacts/mobileagent-cloud-only-debug.apk：原工程经cloud-only构建修复后的调试APK，仅作来源对照，不是主APK接入成果。
- DELIVERY_MANIFEST.json：整包文件长度与SHA256；清单自身不列入。

测试使用的大模型权重、llama.cpp可执行文件、Android SDK/AVD、JDK、Gradle缓存不随包分发。它们属于可下载的环境，不是已完成App/云端源码；模型版本/官方来源/哈希见 b_agent_handoff/tests/evidence/model-provenance.json，启动命令见 tests/start-local-model.ps1。首次源码构建需网络下载工具链依赖。

## 当前完成了什么

B 模块已可作为Android Library接入；复用上游截图/控件/模型/动作/Reflector逻辑，增加困难规则、目标询问、B确认和A抢占。当前仅开放一个明确Click，确认后重新读屏、执行一次、反思、停止。15项JVM测试与5项Android模拟器测试通过，压缩包解压后重新构建和复测也通过。真实视觉闭环使用公开Qwen模型，并非固定JSON。

这不是完整眼镜产品，也不是已经部署的生产云。主APK、眼镜固件和团队云端原始工程未提供，本包不能替代这些尚缺工程。示例联系人页面用于验收B链路，没有实现真实视频通话。

## Android队友负责

- 将 android_library 与 integration 导入主项目，接入现有AccessibilityService及截图，避免重复注册服务。
- 接通现有BLE B按钮、ASR文本、TTS/UI回调；保留发起录音时的task_id/prompt_id/source_button绑定，不能套用最新编号。
- A开始前通知B，A结束不恢复旧候选；同步处理生命周期、授权、后台/前台状态。
- 接上团队模型配置；配置由主APK管理，不能把生产长期密钥写死在公开源码。
- 在目标手机和真实第三方App逐项验收；隐藏会改变截图的自身提示覆盖层。当前仅Click，滑动/输入/长按不应未经设计直接开放。

## 云端队友负责

按 CLOUD_HANDOFF.md 提供可理解图片的OpenAI兼容服务。可直接连接已有模型API；如需自部署，可使用现成推理服务。没有必须新建数据库、用户系统或Python后端的B模块要求。生产鉴权、可达HTTPS地址、限流/超时/失败处理和必要的截图数据政策由团队补齐。

## 推荐联调顺序

1. JDK17 + Android SDK34，构建两个模块与sample_app；运行15项JVM测试。
2. 启动视觉服务，按 tests/README.md 在模拟器跑5项验收。真实模型项没有可用endpoint会失败，不可改成固定答案充数。
3. 主APK先完成主动B求助，再接自动困难询问；确认前必须重读真实页面。
4. 真机验证拒绝、换页、超时、重复转写、A抢占和截图权限失败均不误点。
5. 再接真实BLE/ASR/TTS与目标业务App；整条视频通话的产品流程需另行完成和验收。

测试APK为debug签名，不是发布签名。未声称真机OEM、实际眼镜硬件、生产云或第三方App已完成端到端验收。
