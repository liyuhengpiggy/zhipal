# 云端和视觉API交接

## 现有Android客户端的真实契约

源码：b_agent_handoff/android_library/src/main/java/com/mobileagent/app/api/OpenAiCompatibleClient.kt 与 ApiConfig.kt。

- 配置字段：endpoint、model、apiKey。endpoint可设为 https://团队域名/v1，客户端追加 /chat/completions；若已以 /chat/completions 结尾则直接使用。不自动补/v1。
- HTTP POST，Content-Type: application/json，Authorization: Bearer <apiKey>。
- JSON请求：model、messages、max_tokens=4096。不使用stream字段；当前需要完整JSON响应，不接SSE流。
- messages可含system文本；user.content为数组，含image_url对象及text对象。图片以 data:image/jpeg;base64,... 传输。Reflector一次请求含前/后两张图，服务必须支持多图片。
- 响应读取 choices[0].message.content，必须是字符串；模型文本遵守原Manager/Executor/Reflector输出标题。具体格式见 b_agent_handoff/android_library/src/main/java/com/mobileagent/app/agent/PromptConstants.kt 和归档真实prompt/response。
- 输出动作必须在当前真实可点击目标列表内；当前B只允许一个明确Click。模型不能负责绕过确认，也不能让云端直接控制设备。手势只在Android确认和页面复核后发出。
- 连接30秒、写入30秒、读取120秒；最多2次HTTP尝试。A抢占或取消会取消客户端请求。服务应合理应对客户端断开；网络重试不等于动作重试。

## 可复现的公开模型参考

本次测试：Qwen官方 Qwen3-VL-2B-Instruct-GGUF，revision=52d6c8ffea26cc873ac5ad116f8631268d7eb503；Q4_K_M模型加Q8_0视觉投影，现成llama.cpp b11840 Vulkan运行时。模型/投影哈希、下载来源和许可证在 tests/evidence/model-provenance.json、model-upstream-metadata.json 与 THIRD_PARTY_LICENSES/ 中。

权重来自 https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct-GGUF ，运行时来自 https://github.com/ggml-org/llama.cpp 。如继续用此版本，按归档revision与哈希校验文件，不应以浮动最新版替代已验证配置。

脚本 b_agent_handoff/tests/start-local-model.ps1 接收已有的 llama-server.exe、ModelFile、ProjectorFile。现成服务使用 --alias qwen3-vl-2b --host 127.0.0.1 --port 8087 --ctx-size 12288 --parallel 1 --jinja --reasoning-budget 0，完整已测命令见脚本；Windows脚本使用 -c 12288。通过adb reverse tcp:8087 tcp:8087让模拟器访问本机。localhost只用于开发，不能填到其他人的实体手机当成云端地址。

## 尚需团队决定和实现

- 选择现有云模型API或自部署模型服务，提供手机可访问的HTTPS地址、模型名和鉴权方案。
- 评估目标App截图上的识别准确性、坐标遵循、延迟、吞吐和成本；本次单一联系人页面的成功不能代表通用准确率。
- 如使用服务端代理，保护真实供应商密钥、限制请求大小和速率；不得将截图或转写内容无必要地写入日志。
- 决定截图保存/删除策略及用户告知；B模块本身只保留临时内存，不要求正式数据库。
- 验证401/403、429、5xx、断网、空响应、异常格式及取消。格式错误或页面变化时应停止，不能降级为盲点。

本包没有伪造云服务或生产配置；生产App和云端接通仍是待完成工作。
