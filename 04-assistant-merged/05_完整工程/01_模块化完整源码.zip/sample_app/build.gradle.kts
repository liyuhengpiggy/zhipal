import java.util.Properties
plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val modelProperties = Properties().apply {
 rootProject.file("model.local.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}
val demoKey = modelProperties.getProperty("api.key", "")
fun quoted(value: String) = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""
android {
 namespace = "com.bagent.sample"
 compileSdk = 34
 buildFeatures { buildConfig = true }
 defaultConfig { buildConfigField("String", "MODEL_API_KEY", quoted(demoKey)); applicationId = "com.bagent.sample"; minSdk = 30; targetSdk = 34; versionCode = 5; versionName = "1.3-sdk1"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 implementation(project(":assistant_feature"))
 testImplementation("junit:junit:4.13.2")
 androidTestImplementation("androidx.test:runner:1.5.2")
 androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
 androidTestImplementation("junit:junit:4.13.2")
}
