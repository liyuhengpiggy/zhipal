package com.bagent.sample
import android.app.Activity
import android.os.Bundle
import com.bagent.assistant.AssistantFeature
class MainActivity : Activity() {
 override fun onCreate(state: Bundle?) { super.onCreate(state); AssistantFeature.openSetup(this); finish() }
}
