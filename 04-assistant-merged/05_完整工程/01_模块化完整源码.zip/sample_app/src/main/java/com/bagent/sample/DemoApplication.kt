package com.bagent.sample
import android.app.Application
import com.bagent.assistant.AssistantFeature
import com.mobileagent.app.api.ApiConfig
class DemoApplication : Application() {
 override fun onCreate() {
  super.onCreate()
  if (BuildConfig.MODEL_API_KEY.isNotBlank()) AssistantFeature.configure(this, ApiConfig(
   endpoint="https://api.siliconflow.cn/v1",apiKey=BuildConfig.MODEL_API_KEY,model="Qwen/Qwen3-VL-32B-Instruct",
   maxSteps=1,maxOutputTokens=96,temperature=0.1,imageLongSide=1152,jpegQuality=78,requestTimeoutSeconds=40))
 }
}
