package com.bagent.sample

import android.content.Intent
import com.bagent.assistant.*
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import org.junit.Assert.*
import org.junit.Test
import org.junit.Assume.assumeTrue
import androidx.test.uiautomator.Until
import java.util.concurrent.atomic.AtomicInteger

/** Smoke checks for the current overlay-driven app, without any paid model requests. */
class DeviceAcceptanceTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val device = UiDevice.getInstance(instrumentation)

    @Test fun oneModelDecisionDispatchesExactlyOneNativeClick() {
        assumeTrue("Enable accessibility service before this test",AssistantAccessService.instance != null)
        instrumentation.targetContext.startActivity(Intent(instrumentation.targetContext,DebugClickFixtureActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        assertTrue(device.wait(Until.hasObject(By.text("原生点击测试目标")),3_000))
        val calls=AtomicInteger()
        kotlinx.coroutines.runBlocking(kotlinx.coroutines.Dispatchers.Main) {
            val service=AssistantAccessService.instance!!
            val selected=com.mobileagent.app.controller.UiElementDetector.detectElements(service).single { it.text=="原生点击测试目标" }
            val api=object:com.mobileagent.app.api.VlmApiClient {
                override suspend fun predictWithImages(systemPrompt:String?,textPrompt:String,images:List<android.graphics.Bitmap>):Result<String> {
                    calls.incrementAndGet()
                    return Result.success("{\"target_id\":${selected.index}}")
                }
            }
            // Explicit fake image/model; the fixture views and ACTION_CLICK are real.
            val scope=kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob()+kotlinx.coroutines.Dispatchers.Main)
            val metrics=service.resources.displayMetrics
            val port=com.bagent.android.AndroidAssistPort(service,{
                android.graphics.Bitmap.createBitmap(metrics.widthPixels,metrics.heightPixels,android.graphics.Bitmap.Config.ARGB_8888)
            },api,scope)
            val screen=port.observe()
            try {
                val suggestion=port.suggest("点击回归测试目标",emptyList(),screen)
                assertTrue(port.dispatchOnce(screen,suggestion).await())
                assertEquals("native",port.lastDispatchMode)
            } finally { port.release(screen);scope.coroutineContext[kotlinx.coroutines.Job]?.cancel() }
        }
        assertTrue(device.wait(Until.hasObject(By.text("已点击1次")),3_000))
        assertEquals(1,DebugClickFixtureActivity.clicks)
        assertEquals(1,calls.get())
    }

    @Test fun predictionPanelShowsImmediatelyAndDispatchesOnlyOnce() {
        val context = instrumentation.targetContext
        assumeTrue("Grant overlay permission before this regression test", android.provider.Settings.canDrawOverlays(context))
        device.pressHome()
        val accepted = AtomicInteger()
        val dismissed = AtomicInteger()
        lateinit var panel: FloatingPanelManager
        instrumentation.runOnMainSync {
            panel = FloatingPanelManager(context)
            assertTrue(panel.show("悬浮结果回归测试", "仅测试显示，不点击目标应用",
                onConfirm = { accepted.incrementAndGet() }, onDismiss = { dismissed.incrementAndGet() }))
        }
        try {
            assertTrue(device.wait(Until.hasObject(By.text("悬浮结果回归测试")), 3_000))
            device.findObject(By.text("执行")).click()
            assertTrue(device.wait(Until.gone(By.text("悬浮结果回归测试")), 3_000))
            assertEquals(1, accepted.get())
            assertEquals(0, dismissed.get())
        } finally { instrumentation.runOnMainSync { panel.dismiss() } }
    }

    @Test fun setupScreenShowsCurrentTriggerAndPermissions() {
        instrumentation.targetContext.startActivity(
            Intent(instrumentation.targetContext, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        device.waitForIdle()
        assertTrue(device.hasObject(By.text("智能助手")))
        assertTrue(device.hasObject(By.text("2. 授权屏幕截图（录屏）")))
        assertFalse(device.hasObject(By.textContains("三连击")))
    }

    @Test fun dialogWithoutLiveProposalCanBeCancelledSafely() {
        instrumentation.targetContext.startActivity(
            Intent(instrumentation.targetContext, ConfirmDialogActivity::class.java)
                .putExtra(ConfirmDialogActivity.EXTRA_REQUEST_ID, -1L)
                .putExtra(ConfirmDialogActivity.EXTRA_DESCRIPTION, "回归测试，不执行动作")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        device.waitForIdle()
        assertTrue(device.hasObject(By.text("预测的下一步操作")))
        device.findObject(By.text("取消")).click()
        device.waitForIdle()
        assertFalse(device.hasObject(By.text("预测的下一步操作")))
    }
}
