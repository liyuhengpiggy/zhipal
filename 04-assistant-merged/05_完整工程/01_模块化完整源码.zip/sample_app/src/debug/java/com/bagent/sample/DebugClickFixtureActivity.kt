package com.bagent.sample

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Internal debug-only target for real accessibility clicks; no model or external app. */
class DebugClickFixtureActivity : Activity() {
    companion object { var clicks = 0 }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        clicks = 0
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        layout.addView(TextView(this).apply { text="原生点击回归页面" })
        layout.addView(Button(this).apply {
            text="原生点击测试目标"
            setOnClickListener { clicks++;text="已点击${clicks}次" }
        })
        setContentView(layout)
    }
}
