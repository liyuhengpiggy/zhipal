# 真实测试报告

日期：2026-10-24 Asia/Shanghai。日志/JUnit/设备内部时间为2026-10-23的UTC时钟（时区差异），不是另一天的重用结果。

## 环境与构建

Windows、JDK17.0.20.1、Gradle8.7、AGP8.5.2、Kotlin1.9.22、Android SDK34、API34 google_apis x86_64模拟器（WHPX，720×1280）。原项目commit31e3662d4bec9d8101997a2bd6f63a2c6d04e153。

| 项目 | 实际结果 | 证据 |
|---|---|---|
| 原工程最初assembleDebug | 失败：空release签名路径，及native工具链要求 | 来源说明和构建补丁 |
| 原工程cloud-only补丁后APK | BUILD SUCCESSFUL；已安装并冷启动Status:ok，1078ms | evidence/upstream-cloud-build.log、upstream-launch.log |
| Library release AAR / sample APK / test APK / integration JAR | BUILD SUCCESSFUL | evidence/build.log、artifacts/ |
| JVM规则/状态/编号/取消等 | 15/15通过，0失败/0错误 | evidence/unit-tests.xml |
| 同一最终APK的模拟器测试 | 5/5通过，38.687秒 | evidence/device-acceptance.log |

## 核心验收

| 要求 | 实际操作与结果 | 模型性质 |
|---|---|---|
| 自动发现困难 | UiAutomator真实点击无效按钮三次，AccessibilityEvent触发repeated_click_without_progress，回调GOAL询问，未点击/未调用模型 | 无模型 |
| 真实截图建议 | 原OpenAiCompatibleClient经localhost/v1/chat/completions发送模拟器真实标注截图、真实控件列表和用户目标；原Manager/Executor解析模型回复为Click[360,374]，目标真实按钮“女儿” | 公开Qwen3-VL-2B Q4_K_M真实推理 |
| 确认且单步停止 | 同prompt连续3次“对”；后2次被忽略；确认重截图，通过校验后原手势只点一次，实际计数1，真实进入“女儿的联系方式” | 真API+真截图+真手势 |
| 执行验证 | 原Reflector接收前后两张真实截图，模型输出Outcome A；回调single_step_complete；等待后仍计数1，视频按钮未自动点击 | 真API |
| 拒绝 | “不用了”后无手势，无点击 | 明确mock建议；真设备/真截图 |
| 换页失效 | 用户先真实手动打开联系人，再确认旧建议，stale_page，B dispatch数0（用户自己的一次点击不算B） | 明确mock建议；真换页/真截图 |
| A/B隔离 | A开始即失效；A结束后旧prompt仍无效，无B点击 | 明确mock建议；真设备 |

真实模型一轮三次请求（Manager、Executor、Reflector）。输入/响应/图片保存在evidence/device/real-*；执行事件含相同task/prompt绑定、两次speech_ignored、一次action_dispatched、一次A结果、一次stopped。没有以mock冒充真实模型。

## 模型来源与失败修复

测试主机没有团队API凭据。自行下载Qwen官方GGUF及视觉投影，用现成llama.cpp b11840 Windows Vulkan binary启动本机API，再adb reverse接入原Android HTTP客户端。并未训练模型，也没有新建Python后端或数据库。两个权重SHA256与官方HF LFS元数据一致，revision和哈希见model-provenance.json。

初次真实推理失败：调试面板被模型误认为任务按钮，坐标[540,819]不等于真实中心[360,819]；模块报ambiguous_or_unlisted_target并停止，未点击。诊断原输出保留。后续让验收页面仅展示正常联系人，B桥动态附加真实控件可选JSON与画面尺寸；模型自行返回[360,374]，没有固定正确答案。一次单独真实验收92.713秒通过，随后最终全套5项38.687秒通过（已热身）。样本很小，不代表复杂第三方应用的准确率。

## 单元覆盖补充

规则：三次无进展点击、真实进展不误报、ABABAB、阅读等待不触发。
状态：确认只一步/不续跑、重复prompt、拒绝、页面变化、A废弃建议、A取消模型分析、错task/prompt/source、未知文字、超时、不是这个、无目标说对。
资源：建议/执行结束释放，确认后协程启动前被A取消仍释放截图。15项为测试函数数量，其中函数可验证多项不变量。

## 边界和未验收项

- 只证明本轮单个Click帮助闭环；不会自动完成整条视频通话任务，也没有真实拨号/视频通信。
- 没有用户主APK或眼镜BLE、ASR、TTS源工程，未声称完成其端到端集成；已有可编译服务接入样例。
- 未测真机OEM后台限制、API26–29主APK截图授权、复杂第三方App、多语言鲁棒性。
- 原工程完整JNI/NDK30端侧模型构建未通过；本次复用的是已构建的cloud兼容API路径。
- A开始后不能回滚Android已接收的那一次物理手势；保证取消未发出动作与后续流程。
- 严格画面一致性可能因动态状态栏/动画/主APK覆盖层而保守拒绝，需重新读屏建议。
- 已从ZIP全新解压至 E:\b_agent_dev\verify_handoff\b_agent_handoff，111项清单哈希一致。独立重建113项任务实际执行，BUILD SUCCESSFUL（22秒）；JVM仍为15/15通过。
- 解压目录构建APK已重新安装并调用真实模型，5/5模拟器测试再次通过（29.357秒）。日志见evidence/repack-verification.log、repack-device.log和repack-unit-tests.xml；本轮截图/模型原始输出见evidence/repack-device/。最终ZIP仅追加本次文档/证据，已测试源码保持相同。
