# 智能助手 1.1（2026-10-25）

本文件描述本轮实际交付。原 README、TEST_REPORT 和 tests/ 中旧材料仅作历史参考，不能当作 1.1 的测试结论。

## 本轮修复

1. 移除残留的三连击自动预测，只通过悬浮按钮触发，避免普通连续操作误触发。
2. 确认按钮先关闭窗口，服务等待目标应用恢复后重新截图、核对控件树，再提交一次点击。弹窗使用独立任务并清理旧弹窗栈。
3. 增加预测、待确认、执行互斥；每次确认绑定请求编号；确认 60 秒过期并释放截图；预测 90 秒超时；手势回调等待上限 5 秒。
4. 修复返回键关闭确认框后截图未释放；中断或销毁服务时取消任务并清理资源；修复单任务弹窗复用时仍显示旧内容。
5. 修复悬浮图标触摸监听吞掉长按事件的问题，支持长按关闭、拖动取消长按、触摸取消清理和拖动边界限制。截图与执行期间暂时隐藏图标。
6. Android 14 先以 specialUse 类型启动无障碍前台服务，收到录屏授权后才提升为 mediaProjection；Android 14 请求整个屏幕，避免单应用截图与屏幕点击坐标不一致。
7. 所有支持版本都注册录屏停止回调；录屏就绪状态读取实际资源状态；授权失败不再显示成功；无障碍未连接时不申请录屏。
8. 持续读取最新录屏帧并保留一帧，兼顾静止页面和连续截图；释放对齐裁剪产生的中间位图。屏幕方向或分辨率改变时拒绝旧坐标并提示重新授权。
9. 页面指纹改为应用和可访问控件内容、位置、状态，避免时钟、光标闪烁等像素变化取消执行；点击前仍要求控件树和目标完全匹配。无障碍树无法表达的纯画布变化不在这个指纹的覆盖范围内。
10. 排除助手自己的操作事件和预测过程事件，避免淹没近期用户点击历史；移除点击完成后不必要的模型反思请求。手势拒绝、超时、完成分别反馈，完成仅表示系统手势回调完成。
11. 权限页使用真实系统无障碍状态，并同时检查悬浮窗权限和图标是否运行；改为可滚动布局。
12. 更新已经失效的设备测试代码，保留原测试为 tests/DeviceAcceptanceTest.legacy.kt.txt。

## 构建与测试

需要 JDK 17、Android SDK Platform 34、Build Tools 34.0.0、Gradle 8.7。在 local.properties 设置 sdk.dir，或通过 ANDROID_HOME 指定 SDK。

```powershell
gradle :sample_app:assembleDebug :sample_app:testDebugUnitTest :integration:test :sample_app:assembleDebugAndroidTest
gradle :sample_app:lintDebug
```

输出 APK：sample_app/build/outputs/apk/debug/sample_app-debug.apk。
包名 com.bagent.sample，versionCode 2，versionName 1.1，最低 Android API 30。
最终测试状态见同交付目录的《修复与验证说明.md》。设备测试编译成功不等于已在设备上执行。

## 安装验收

1. 安装 1.1，打开应用，依次开启无障碍、录屏授权、悬浮窗权限、通知权限，并启动图标。
2. 切换到目标应用，再点击悬浮图标。等待模型返回确认窗口。
3. 先测试取消和返回键：均不得点击目标。再测试确认：窗口关闭后只点击一次所提示目标。
4. 确认前切换应用或改变页面，操作必须取消；超过 60 秒的确认必须失效；连续点击图标不得并发预测。
5. 长按图标应关闭；停止录屏后刷新状态应显示未就绪；重新授权后可重试；旋转屏幕后应提示重新授权。
6. 鸿蒙后台管理、模型返回内容、网络、真实页面确认与手势执行仍需手机验证。

## 交接资料勘误

原 HANDOFF 把 AccessibilityService.takeScreenshot() 写成 Android 14 新增接口，这不正确；Android 官方标注为 API 30。本轮继续保留 MediaProjection 路径，没有据此宣称鸿蒙必然不支持该接口。

官方依据：
- https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- https://developer.android.com/media/grow/media-projection
