# 主 APK 接入

## 推荐：导入两个源码模块

复制 android_library/ 与 integration/ 到现有项目，保留本包 THIRD_PARTY_LICENSES 与来源说明。合并固定版本依赖，按主项目已有版本做冲突评估；本交付使用 JVM17 / compileSdk34 / Library minSdk26。

```kotlin
// settings.gradle.kts
include(":android_library", ":integration")
// 主 app/build.gradle.kts
implementation(project(":android_library"))
```

android_library 已通过 api(project(":integration")) 传递 B 公共类型。只复制 AAR **不会** 自动打包 integration JAR 或依赖。二进制接入须同时包含 artifacts/integration.jar 与 runtime-dependencies/ 中依赖（剔除同坐标重复版本，AAR 按 Gradle AAR 规则导入）。优先源码接入，避免 flatDir 丢失依赖元数据。

## 复用主 APK 已有无障碍服务

Library manifest 仅声明 INTERNET，不声明 AccessibilityService。主 APK 已有服务需要 canRetrieveWindowContent、canPerformGestures、FLAG_REPORT_VIEW_IDS；若使用系统 takeScreenshot 需要 API30+ 和 canTakeScreenshot=true。minSdk26 只表示 Library 的兼容下限；26–29 由主 APK 提供已有且合法授权的 MediaProjection 截图。原 ScreenCaptureManager 作为可选源码保留，不在 B 路径发起授权。

```kotlin
import com.bagent.android.BAssist
import com.bagent.integration.*
import com.mobileagent.app.api.ApiConfig

// 以下置于主 APK 现有 AccessibilityService；全部 B 入口在 Main 调用。
private var b: BAssist? = null
fun initializeB(endpoint: String, model: String, secret: String) {
    b?.close()
    b = BAssist(
        service = this,
        screenshot = { captureOwnedScreenBitmap() }, // 主 APK 实现：新 Bitmap，所有权转移给 B
        config = ApiConfig(endpoint = endpoint, model = model, apiKey = secret),
        listener = object : AssistListener {
            override fun onPrompt(prompt: AssistPrompt) {
                // 存储完整 taskId/promptId；送入已有 UI/TTS。
                showAndSpeakWithExistingTts(prompt)
            }
            override fun onEvent(event: AssistEvent) {
                // stopped 清除主 APK 旧问题；execution_result 更新执行反馈。
                handleBEvent(event)
            }
        }
    ).also { it.startObserving() }
}
override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    if (event != null) b?.onAccessibilityEvent(event)
    // 保留主 APK 原有处理。
}
fun onExistingBAsr(taskId: String, promptId: String, transcript: String) {
    b?.onBSpeechResult(taskId, promptId, "B", transcript)
}
fun beforeStartingExistingATask() { b?.onATaskStarted() }
fun afterFinishingExistingATask() { b?.onATaskFinished() }
override fun onInterrupt() { b?.cancelAssist() }
override fun onDestroy() { b?.close(); b = null; super.onDestroy() }
```

captureOwnedScreenBitmap、showAndSpeakWithExistingTts、handleBEvent 是主 APK 的接入位置示例，不是本库伪造的现有 API；sample_app/SampleAccessService.kt 提供可编译的 API30 takeScreenshot 实例（关闭 HardwareBuffer、处理取消、复制 ARGB8888）。不要将 sample_app 的服务直接复制到已有双服务架构中。

BLE B 按下时主 APK 生成新的 task_id 调 onBHelpRequested。播报时保存回调的 prompt_id；ASR 返回使用当时绑定的编号，**不能补填当前最新编号来接受旧录音**。A 开始必须先在 Main 调 B 的 onATaskStarted，再启动 A。硬件/ASR/TTS 实现均归主 APK。

## 并发与截图注意

所有入口、回调、currentPrompt 访问遵守 Android Main；示例以 Dispatchers.Main.immediate 保证最终校验到 dispatchGesture 之间无挂起。截图提供器必须可取消，不得返回主 APK 后续还要使用的共享 Bitmap；不截屏时返回 null，B 停止，不退化到盲点。

若主 APK 自身提示/悬浮窗/输入框覆盖目标，先隐藏并等画面稳定再请求分析；确认时页面发生任何变化都会保守失效。系统动态状态栏或动画可能导致拒绝旧候选，需要重新请求帮助；不会为了命中而放宽校验。

A 发生在 platform 已接收手势后，Android 不能撤销已经提交的那一次手势；B 会取消等待/反思并保证不再开始其他手势。A 的事件通知和 B 的入口必须在同一 Main 线程序列化。

## 模型与网络

生产用 HTTPS 视觉模型。客户端保留上游图片编码、OpenAI 请求和响应解析；网络等待改为可取消 OkHttp enqueue，连接30秒/读取120秒，最多2次 HTTP尝试（重试的是分析请求，不是点击）。endpoint 不自动插入 /v1。Demo debug 只为 localhost/127.0.0.1 放行明文，正式库和 release 不放行任意明文。

模型必须能理解图片并按上游 Manager/Executor/Reflector 标题格式返回；不符合格式将拒绝。ApiConfig.maxSteps 为上游遗留字段，本 B 调度不会使用它继续执行。首次接入请用 tests/run-device-tests.ps1 复现，再到实际业务页面验收。
