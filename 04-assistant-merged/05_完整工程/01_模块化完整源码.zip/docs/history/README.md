# B 单步帮助模块（Android Library）

开发日期：2026-10-24（Asia/Shanghai）。工程位于 E:\b_agent_dev\b_agent_handoff。

这是 MobileAgent-Android 核心代码的移植、裁剪和 B 确认适配。正式接入点是 android_library 与 integration；sample_app 只用于演示和自动化验收。

## 实现范围

- 监听主 APK 转发的 AccessibilityEvent，最多缓存 32 条 / 20 秒事件；10 秒同控件三次点击且页面签名均未变化、六次 ABABAB 页面往返可触发“疑似困难”，60 秒冷却。阅读、等待不会单独触发。
- 用户主动 B 求助不依赖规则触发。未知目标先提问，B ASR 文本补充目标。
- 原 Manager → 原 Executor → 原响应解析器给出当前页面的单步建议，等待当前 task_id / prompt_id / source_button=B 的“对”。
- 确认前消费编号，重截图并核对窗口、控件树和画面指纹，复用原 dispatchGesture 点击一次，再调用原 Reflector 比较前后截图并停止。没有连续执行循环。
- A 开始取消 B 的挂起分析/网络请求并废弃待确认建议；A 结束不恢复旧建议。

**本版公开 B 动作仅支持一个明确、有文字/描述、可用且唯一匹配的 Click。** 原项目滑动、输入、长按源码保留供后续扩展，但本版拒绝其 B 建议。目标模糊、模型格式错误、密码控件、多个动作均停止；不使用坐标兜底或预设答案。

## 构建

要求 JDK 17、Android SDK platform 34/build-tools 34.0.0；Gradle 8.7、AGP 8.5.2、Kotlin 1.9.22。设置 ANDROID_HOME 或本地 local.properties（不要提交机器路径）。

```powershell
.\gradlew.bat :integration:test :android_library:assembleRelease :sample_app:assembleDebug :sample_app:assembleDebugAndroidTest
```

首次源码构建需要下载 Gradle 插件和固定版本依赖。artifacts/ 提供已构建 AAR、integration JAR、示例 APK、测试 APK 及 runtime-dependencies 原始依赖包；不包含 SDK/JDK/模型大文件，不承诺离线重建 Gradle 工具链。APK 同学优先按 APK_INTEGRATION.md 使用源码模块。

## 配置与安全边界

使用调用方现有 OpenAI 兼容视觉 API，endpoint 传 .../v1 或完整 .../chat/completions，model 与 apiKey 由主 APK 配置。model.local.properties.example 仅作配置字段示意，不自动加载；凭据不要写入源码或仓库。

模块不会实现 BLE/ASR/TTS，不访问眼镜摄像头，不创建数据库、不搭建正式后端、不注册另一套无障碍服务。近期历史、屏幕和建议只在进程内存中；截图会提交至调用方配置的模型，主 APK 负责用户告知和访问授权。测试证据只包含自建模拟器页面。

测试使用公开 Qwen3-VL-2B-Instruct-GGUF + 现成 llama.cpp llama-server 的本机 OpenAI 兼容接口，不是自建 Python 后端，也不是 APK 的运行依赖。真实结果及失败记录见 TEST_REPORT.md。

## 文档与目录

- APK_INTEGRATION.md：已有 AccessibilityService 的接入代码、依赖和生命周期。
- API_CONTRACT.md：绑定、超时、取消和回调契约。
- UPSTREAM_SOURCES.md / upstream-files.json：原仓库、commit、原文件/本地 SHA256 与改动。
- tests/：单元测试和模拟器脚本、原始输出、模型输入输出与截图。
- THIRD_PARTY_LICENSES/：上游 MIT、依赖/测试工具来源与许可证。
- upstream_patches/：原工程构建补丁、移植差异。

这不是视频通话产品或任意 App 的准确率承诺。测试中的联系人/视频按钮是允许自建的 Android View 场景；最终主 APK、真实 BLE/ASR/TTS 和第三方 App 需由接入方验收。
