package com.mobileagent.app.api

import android.graphics.Bitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class OpenAiCompatibleClient(private val config: ApiConfig) : VlmApiClient {
    data class RequestStats(val attempts: Int, val elapsedMs: Long, val requestBytes: Long, val outputTokens: Int, val traceId: String)
    @Volatile var lastStats: RequestStats? = null
        private set
    private class HttpFailure(val status: Int, message: String) : IOException(message)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .callTimeout(config.requestTimeoutSeconds, TimeUnit.SECONDS)
        .readTimeout(config.requestTimeoutSeconds, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun predictWithImages(
        systemPrompt: String?,
        textPrompt: String,
        images: List<Bitmap>
    ): Result<String> = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        lastStats = null
        val started = System.nanoTime()
        val request = try { buildRequest(systemPrompt, textPrompt, images) }
            catch (e: Exception) { return@withContext Result.failure(e) }

        repeat(MAX_RETRIES) { attempt ->
            lastStats = RequestStats(attempt + 1, (System.nanoTime() - started) / 1_000_000,
                request.body?.contentLength() ?: 0, 0, "")
            try {
                val result = doRequest(request)
                lastStats = lastStats?.copy(attempts = attempt + 1, elapsedMs = (System.nanoTime() - started) / 1_000_000)
                return@withContext Result.success(result)
            } catch (e: CancellationException) {
                lastStats = lastStats?.copy(elapsedMs = (System.nanoTime() - started) / 1_000_000)
                throw e
            } catch (e: Exception) {
                lastError = e
                lastStats = lastStats?.copy(elapsedMs = (System.nanoTime() - started) / 1_000_000)
                val retryable = if (e is HttpFailure) e.status == 429 || e.status in 500..599 else e is IOException
                if (!retryable) return@withContext Result.failure(e)
                if (attempt < MAX_RETRIES - 1) {
                    delay(RETRY_DELAY_MS)
                }
            }
        }
        Result.failure(lastError ?: Exception("Unknown error"))
    }

    private fun buildRequest(
        systemPrompt: String?,
        textPrompt: String,
        images: List<Bitmap>
    ): Request {
        val messages = buildJsonArray {
            if (systemPrompt != null) {
                addJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                }
            }
            addJsonObject {
                put("role", "user")
                put("content", buildJsonArray {
                    for (image in images) {
                        addJsonObject {
                            put("type", "image_url")
                            putJsonObject("image_url") {
                                put("url", "data:image/jpeg;base64,${ImageEncoder.encode(image, config.imageLongSide, config.jpegQuality)}")
                            }
                        }
                    }
                    addJsonObject {
                        put("type", "text")
                        put("text", textPrompt)
                    }
                })
            }
        }

        val requestBody = buildJsonObject {
            put("model", config.model)
            put("messages", messages)
            put("max_tokens", config.maxOutputTokens)
            config.temperature?.let { put("temperature", it) }
        }

        val endpoint = config.endpoint.trimEnd('/')
        val url = if (endpoint.endsWith("/chat/completions")) endpoint
        else "$endpoint/chat/completions"

        return Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer ${config.apiKey}")
            .addHeader("Content-Type", "application/json")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private suspend fun doRequest(request: Request): String {
        val response = suspendCancellableCoroutine<Response> { continuation ->
            val call = client.newCall(request)
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { if (continuation.isActive) continuation.resumeWithException(e) }
                override fun onResponse(call: Call, response: Response) {
                    if (continuation.isActive) continuation.resume(response) { response.close() } else response.close()
                }
            })
        }
        return response.use {
        val body = response.body?.string() ?: throw Exception("Empty response body")

        if (!response.isSuccessful) {
            throw HttpFailure(response.code, "API error ${response.code}: ${body.take(400).replace(config.apiKey.ifBlank { "[no-key]" }, "[redacted]")}")
        }

        val jsonResponse = json.parseToJsonElement(body).jsonObject
        val choice = jsonResponse["choices"]?.jsonArray?.firstOrNull()?.jsonObject ?: error("模型未返回候选结果")
        require(choice["finish_reason"]?.jsonPrimitive?.content != "length") { "模型输出被截断，请重试" }
        lastStats = RequestStats(1, 0, request.body?.contentLength() ?: 0,
            jsonResponse["usage"]?.jsonObject?.get("completion_tokens")?.jsonPrimitive?.intOrNull ?: 0,
            response.header("x-siliconcloud-trace-id").orEmpty().take(120))
        choice["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
            ?.takeIf { it.isNotBlank() } ?: error("模型返回空结果")
        }
    }

    companion object {
        private const val MAX_RETRIES = 2
        private const val RETRY_DELAY_MS = 1_000L
    }
}
