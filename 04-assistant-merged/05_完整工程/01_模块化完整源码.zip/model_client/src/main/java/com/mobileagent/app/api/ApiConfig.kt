package com.mobileagent.app.api

import kotlinx.serialization.Serializable

@Serializable
data class ApiConfig(
    val provider: String = "openai",
    val endpoint: String = "",
    val apiKey: String = "",
    val model: String = "",
    val coordType: String = "absolute",
    val maxSteps: Int = 25,
    val enableNotetaker: Boolean = true,
    val agentMode: Int = 1,
    val localModelId: String = "qwen3-vl-2b",
    val maxOutputTokens: Int = 4096,
    val temperature: Double? = null,
    val imageLongSide: Int = 1344,
    val jpegQuality: Int = 85,
    val requestTimeoutSeconds: Long = 120
)
