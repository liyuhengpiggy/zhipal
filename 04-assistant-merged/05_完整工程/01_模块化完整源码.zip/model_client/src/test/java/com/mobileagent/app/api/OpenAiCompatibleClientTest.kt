package com.mobileagent.app.api

import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class OpenAiCompatibleClientTest {
    private fun client(fixture: LocalHttpFixture) = OpenAiCompatibleClient(ApiConfig(endpoint=fixture.endpoint,apiKey="test-only",model="fixture",maxOutputTokens=96,temperature=0.1,requestTimeoutSeconds=5))
    private val valid = """{"choices":[{"finish_reason":"stop","message":{"content":"{\"target_id\":1}"}}],"usage":{"completion_tokens":8}}"""

    @Test fun sendsShortRequestAndRecordsResponseMetrics() {
        LocalHttpFixture { body,_ ->
            val json=Json.parseToJsonElement(body).jsonObject
            assertEquals(96,json.getValue("max_tokens").jsonPrimitive.int)
            assertEquals(0.1,json.getValue("temperature").jsonPrimitive.double,0.0)
            200 to valid
        }.use { fixture ->
            val client=client(fixture)
            assertTrue(runBlocking { client.predictWithImages("system","prompt",emptyList()) }.isSuccess)
            assertEquals(1,fixture.count.get());assertEquals(8,client.lastStats?.outputTokens)
            assertEquals("fixture-trace",client.lastStats?.traceId)
        }
    }
    @Test fun forbiddenDoesNotRetryOrExposeKey() {
        LocalHttpFixture { _,_ -> 403 to "bad test-only" }.use { fixture ->
            val result=runBlocking { client(fixture).predictWithImages(null,"prompt",emptyList()) }
            assertTrue(result.isFailure);assertEquals(1,fixture.count.get())
            assertFalse(result.exceptionOrNull()!!.message!!.contains("test-only"))
        }
    }
    @Test fun transientServerErrorRetriesSameRequestOnce() {
        val bodies=java.util.Collections.synchronizedList(mutableListOf<String>())
        LocalHttpFixture { body,number -> bodies.add(body);if(number==1) 503 to "busy" else 200 to valid }.use { fixture ->
            val client=client(fixture)
            assertTrue(runBlocking { client.predictWithImages(null,"prompt",emptyList()) }.isSuccess)
            assertEquals(2,fixture.count.get());assertEquals(bodies[0],bodies[1]);assertEquals(2,client.lastStats?.attempts)
        }
    }
    @Test fun truncatedOutputDoesNotBecomeAProposalOrRetry() {
        LocalHttpFixture { _,_ -> 200 to valid.replace("\"stop\"","\"length\"") }.use { fixture ->
            assertTrue(runBlocking { client(fixture).predictWithImages(null,"prompt",emptyList()) }.isFailure)
            assertEquals(1,fixture.count.get())
        }
    }
}
