package com.mobileagent.app.api

import java.io.Closeable
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/** Local deterministic HTTP fixture; never connects to a paid provider. */
class LocalHttpFixture(private val respond: (String,Int) -> Pair<Int,String>) : Closeable {
    private val server = ServerSocket(0)
    val endpoint = "http://127.0.0.1:${server.localPort}/v1"
    val count = AtomicInteger()
    @Volatile private var failure: Throwable? = null
    private val worker = thread(isDaemon=true) {
        while (!server.isClosed) {
            val socket = try { server.accept() } catch (_: Exception) { break }
            socket.use {
                try {
                    socket.soTimeout=5_000
                    val input=socket.getInputStream()
                    val header=StringBuilder()
                    while (!header.endsWith("\r\n\r\n")) {
                        val c=input.read();check(c>=0 && header.length<65536);header.append(c.toChar())
                    }
                    val size=Regex("Content-Length: (\\d+)",RegexOption.IGNORE_CASE).find(header)?.groupValues?.get(1)?.toInt() ?: 0
                    val bytes=ByteArray(size);var offset=0
                    while(offset<size) { val n=input.read(bytes,offset,size-offset);check(n>0);offset+=n }
                    val (status,body)=respond(bytes.toString(Charsets.UTF_8),count.incrementAndGet())
                    val payload=body.toByteArray()
                    val output=socket.getOutputStream()
                    output.write("HTTP/1.1 $status Fixture\r\nContent-Type: application/json\r\nContent-Length: ${payload.size}\r\nx-siliconcloud-trace-id: fixture-trace\r\nConnection: close\r\n\r\n".toByteArray())
                    output.write(payload);output.flush()
                } catch(t: Throwable) { failure=t }
            }
        }
    }
    override fun close() { server.close();worker.join(2_000);failure?.let { throw AssertionError("HTTP fixture failed",it) } }
}
