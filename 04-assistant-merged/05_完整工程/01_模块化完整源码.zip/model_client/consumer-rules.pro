# Kotlin serialization uses generated serializers; runtime classes are referenced directly.
