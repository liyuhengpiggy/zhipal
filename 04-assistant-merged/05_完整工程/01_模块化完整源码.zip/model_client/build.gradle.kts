plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.serialization"); id("maven-publish") }
group = "com.bagent"
version = "1.3.0"
android {
 namespace = "com.bagent.model"
 compileSdk = 34
 defaultConfig { minSdk = 26; consumerProguardFiles("consumer-rules.pro") }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 publishing { singleVariant("release") { withSourcesJar() } }
}
dependencies {
 api("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
 implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
 testImplementation("junit:junit:4.13.2")
}
afterEvaluate {
 publishing {
  publications { register<MavenPublication>("release") {
   groupId = "com.bagent"; artifactId = "model-client"; version = "1.3.0"
   from(components["release"])
  } }
  repositories { maven { name = "handoff"; url = uri(rootProject.layout.projectDirectory.dir("dist/maven")) } }
 }
}
