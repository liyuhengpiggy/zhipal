plugins { id("com.android.application");id("org.jetbrains.kotlin.android") }
android {
 namespace="org.example.assistanthost"
 compileSdk=34
 defaultConfig { applicationId="org.example.assistanthost";minSdk=30;targetSdk=34;versionCode=1;versionName="1.0" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget="17" }
 buildTypes { getByName("release") {
  isMinifyEnabled=true
  proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
  // Integration fixture only. Replace with your own release signing in the final product.
  signingConfig=signingConfigs.getByName("debug")
 } }
}
dependencies { implementation("com.bagent:assistant-feature:1.3.0") }
