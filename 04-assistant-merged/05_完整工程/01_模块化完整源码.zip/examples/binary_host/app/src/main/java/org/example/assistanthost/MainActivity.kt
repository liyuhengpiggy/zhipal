package org.example.assistanthost

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.bagent.assistant.AssistantFeature

/** Different applicationId, Maven binaries only, minified release. No real key is embedded. */
class MainActivity : Activity() {
 override fun onCreate(state: Bundle?) {
  super.onCreate(state)
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24) }
  layout.addView(TextView(this).apply { text="此示例验证二进制接入。实际使用前在主程序配置模型，然后开启系统权限。" })
  layout.addView(Button(this).apply {
   text="打开助手权限和功能页面"
   setOnClickListener { AssistantFeature.openSetup(this@MainActivity) }
  })
  setContentView(layout)
 }
}
