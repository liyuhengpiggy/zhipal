pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
 repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
 repositories {
  maven { url = uri(providers.gradleProperty("assistantRepo").orNull ?: "../../dist/maven") }
  google();mavenCentral()
 }
}
rootProject.name="AssistantBinaryHost"
include(":app")
