package com.bagent.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * 错误提示弹窗：显示完整的错误信息，方便定位问题。
 */
class ErrorDialogActivity : Activity() {
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }
    companion object {
        const val EXTRA_MESSAGE = "extra_message"
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val win = window
        win.setGravity(Gravity.CENTER)
        val lp = WindowManager.LayoutParams().apply {
            width = (resources.displayMetrics.widthPixels * 0.9).toInt()
            height = WindowManager.LayoutParams.WRAP_CONTENT
        }
        win.setLayout(lp.width, lp.height)
        win.setBackgroundDrawableResource(android.R.color.transparent)
        setFinishOnTouchOutside(false)

        val msg = intent.getStringExtra(EXTRA_MESSAGE) ?: "未知错误"

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            val bg = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 32f
                setColor(0xFFFFFFFF.toInt())
            }
            background = bg
        }
        layout.addView(TextView(this).apply {
            text = "出错了"
            textSize = 18f
            setTextColor(0xFFCC0000.toInt())
        })
        layout.addView(ScrollView(this).apply {
            addView(TextView(this@ErrorDialogActivity).apply {
                text = msg
                textSize = 14f
                setTextColor(0xFF333333.toInt())
                setPadding(0, 24, 0, 32)
            })
        })
        layout.addView(Button(this).apply {
            text = "关闭"
            setOnClickListener { finish() }
        })
        setContentView(layout)
    }
}
