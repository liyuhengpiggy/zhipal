package com.bagent.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * 独立的悬浮图标前台服务：
 * 不依赖无障碍服务，即使无障碍服务被系统杀掉，悬浮图标依然常驻。
 * 单击图标触发预测；长按关闭图标（同时停止本服务）。
 */
class FloatingService : Service() {
    companion object {
        const val CHANNEL_ID = "bagent_assistant_floating_channel"
        const val NOTIFICATION_ID = 0x424102
        const val ACTION_STOP = "com.bagent.assistant.action.STOP"
        var instance: FloatingService? = null
            private set
    }

    private val floating by lazy { FloatingIconManager(this) }
    private val panel by lazy { FloatingPanelManager(this) }
    fun setIconHidden(hidden: Boolean) = floating.setHidden(hidden)
    fun setStatus(text: String) = floating.setStatus(text)
    fun isIconShowing(): Boolean = floating.isShowing()
    fun dismissPanel() = panel.dismiss()
    fun showConfirmation(description: String, id: Long): Boolean = panel.show(
        "预测的下一步操作", description,
        onConfirm = { AssistantAccessService.instance?.onUserConfirmNextStep(id) },
        onDismiss = { AssistantAccessService.instance?.onUserRejectNextStep(id) }
    )
    fun showMessage(message: String): Boolean = panel.show("智能助手提示", message)

    override fun onCreate() {
        super.onCreate()
        instance = this
        startForegroundService()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        floating.show({ stopSelf() }, { onIconTap() })
        AssistantAccessService.instance?.restoreFloatingUi()
        return START_STICKY
    }

    private fun onIconTap() {
        val access = AssistantAccessService.instance
        if (access == null) {
            if (showMessage("无障碍服务未运行，请到智能助手中重新开启无障碍服务。")) return
            // 无障碍服务未运行，引导用户重新开启
            val intent = Intent(this, ErrorDialogActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            intent.putExtra(ErrorDialogActivity.EXTRA_MESSAGE,
                "无障碍服务未运行！\n\n请打开「智能助手」App，点击「1. 开启无障碍服务」，在系统设置里重新打开开关。\n\n打开后悬浮图标会自动恢复预测功能。")
            try { startActivity(intent) } catch (_: Exception) {}
            return
        }
        access.predictNextStep()
    }

    private fun startForegroundService() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "智能助手悬浮图标", NotificationManager.IMPORTANCE_LOW))
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, AssistantSetupActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)
        val built = notification
            .setContentTitle("智能助手运行中")
            .setContentText("点击悬浮图标预测下一步操作")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, built, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, built)
        }
    }

    override fun onDestroy() {
        panel.dismiss(true)
        floating.close()
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
