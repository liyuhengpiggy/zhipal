package com.bagent.assistant

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.mobileagent.app.api.ApiConfig
import com.mobileagent.app.api.VlmApiClient
import com.mobileagent.app.api.OpenAiCompatibleClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Main-process facade. Call configure in the host Application before opening setup. */
object AssistantFeature {
    private var config: ApiConfig? = null
    private var screenshotProvider: (suspend () -> Bitmap?)? = null
    private var screenshotReady: () -> Boolean = { false }
    private var clientFactory: ((ApiConfig) -> VlmApiClient)? = null
    var hostTaskActive: Boolean = false
        private set
    var allowHostApp: Boolean = false
        private set

    fun defaultCloudConfig(apiKey: String) = ApiConfig(
        endpoint="https://api.siliconflow.cn/v1",apiKey=apiKey,model="Qwen/Qwen3-VL-32B-Instruct",
        maxSteps=1,maxOutputTokens=96,temperature=0.1,imageLongSide=1152,jpegQuality=78,requestTimeoutSeconds=40)

    fun configure(context: Context, modelConfig: ApiConfig, allowHostApplication: Boolean = false) {
        main()
        require(modelConfig.endpoint.isNotBlank() && modelConfig.model.isNotBlank() && modelConfig.apiKey.isNotBlank()) {
            "请提供有效的 endpoint、model 和 apiKey"
        }
        if (config == modelConfig && allowHostApp == allowHostApplication) return
        check(AssistantAccessService.instance?.isBusy() != true) { "助手正在处理任务，请等待完成或先暂停助手" }
        config=modelConfig;allowHostApp=allowHostApplication
        AssistantAccessService.instance?.reloadModelConfiguration()
    }

    internal fun modelConfig(): ApiConfig = config ?: defaultCloudConfig("")
    internal fun modelClient(config: ApiConfig): VlmApiClient = clientFactory?.invoke(config) ?: OpenAiCompatibleClient(config)
    fun installModelClientFactory(factory: ((ApiConfig) -> VlmApiClient)?) {
        main()
        check(AssistantAccessService.instance?.isBusy() != true) { "任务进行中不能切换模型客户端" }
        clientFactory=factory
        AssistantAccessService.instance?.reloadModelConfiguration()
    }
    fun isConfigured(): Boolean = config != null

    /** A borrowed host bitmap is copied; the host retains ownership of its original. */
    fun installScreenshotProvider(provider: (suspend () -> Bitmap?)?, isReady: () -> Boolean = { true }) {
        main()
        check(AssistantAccessService.instance?.isBusy() != true) { "任务进行中不能切换截图来源" }
        AssistantAccessService.instance?.stopLocalCapture()
        screenshotProvider=provider;screenshotReady=if(provider == null) ({ false }) else isReady
    }
    internal fun usesSharedCapture() = screenshotProvider != null
    internal fun sharedCaptureReady() = screenshotProvider != null && runCatching { screenshotReady() }.getOrDefault(false)
    internal suspend fun captureShared(): Bitmap? = screenshotProvider?.invoke()?.copy(Bitmap.Config.ARGB_8888,false)

    fun openSetup(activity: Activity) {
        main();activity.startActivity(Intent(activity,AssistantSetupActivity::class.java))
    }

    /** Await before the host A task acquires the screen. Submitted platform clicks cannot be undone. */
    suspend fun suspendForHostTask() = withContext(Dispatchers.Main.immediate) {
        hostTaskActive=true
        AssistantAccessService.instance?.quiesce()
    }
    fun resumeAfterHostTask() { main();hostTaskActive=false }

    suspend fun stop(context: Context) = withContext(Dispatchers.Main.immediate) {
        AssistantAccessService.instance?.quiesce()
        AssistantAccessService.instance?.stopLocalCapture()
        AssistantAccessService.instance?.stopForeground(android.app.Service.STOP_FOREGROUND_REMOVE)
        context.stopService(Intent(context,FloatingService::class.java))
    }

    data class Status(val configured: Boolean, val accessibilityEnabled: Boolean, val accessibilityConnected: Boolean,
        val overlayGranted: Boolean, val captureReady: Boolean, val iconRunning: Boolean, val busy: Boolean,
        val hostTaskActive: Boolean, val sharedCapture: Boolean)

    fun status(context: Context): Status {
        main()
        val manager=context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled=manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName==context.packageName &&
                it.resolveInfo.serviceInfo.name==AssistantAccessService::class.java.name
        }
        val service=AssistantAccessService.instance
        return Status(isConfigured(),enabled,service!=null,Settings.canDrawOverlays(context),service?.hasScreenCapture()==true,
            FloatingService.instance?.isIconShowing()==true,service?.isBusy()==true,hostTaskActive,usesSharedCapture())
    }
    private fun main() { check(Looper.myLooper()==Looper.getMainLooper()) { "AssistantFeature entry point requires Main" } }
}
