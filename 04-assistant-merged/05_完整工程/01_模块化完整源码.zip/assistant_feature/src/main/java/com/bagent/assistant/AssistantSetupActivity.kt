package com.bagent.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

/**
 * 启动引导页：引导用户开启无障碍服务、录屏授权、悬浮窗权限和通知权限。
 * 配置已内置（SiliconFlow），无需手动填写。
 */
class AssistantSetupActivity : Activity() {
    companion object {
        var isVisible: Boolean = false
            private set
        const val REQUEST_SCREEN_CAPTURE = 2001
        const val REQUEST_NOTIFICATION = 100
    }

    private lateinit var projectionManager: MediaProjectionManager
    private var statusText: TextView? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 32) }
        layout.addView(TextView(this).apply {
            text = "智能助手"
            textSize = 26f
            setTextColor(0xFF111111.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "点击屏幕边缘的悬浮图标，自动预测并帮你完成下一步操作。\n\n使用前请依次开启以下权限："
            textSize = 16f
            setTextColor(0xFF444444.toInt())
            setPadding(0, 16, 0, 16)
        })

        fun button(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply { this.text = text; setOnClickListener { action() } })
        }
        button("1. 开启无障碍服务") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. 授权屏幕截图（录屏）") {
            if (AssistantFeature.usesSharedCapture()) {
                Toast.makeText(this, "已使用主程序截图接口，请在主程序完成录屏授权", Toast.LENGTH_LONG).show()
            } else if (AssistantAccessService.instance == null) {
                Toast.makeText(this, "请先开启无障碍服务，等待服务连接后再授权", Toast.LENGTH_LONG).show()
            } else {
                val captureIntent = if (Build.VERSION.SDK_INT >= 34) {
                    projectionManager.createScreenCaptureIntent(
                        android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay())
                } else projectionManager.createScreenCaptureIntent()
                startActivityForResult(captureIntent, REQUEST_SCREEN_CAPTURE)
            }
        }
        button("3. 开启悬浮窗权限") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show()
            }
        }
        button("4. 开启通知权限（Android 13+）") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATION)
            } else {
                Toast.makeText(this, "无需额外通知权限", Toast.LENGTH_SHORT).show()
            }
        }
        button("5. 启动悬浮图标") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限（第 3 步）", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this, FloatingService::class.java))
                Toast.makeText(this, "悬浮图标已启动，请在目标应用中点击它", Toast.LENGTH_SHORT).show()
                if (AssistantAccessService.instance?.hasScreenCapture() == true) finish()
                else statusText?.postDelayed({ refreshStatus() }, 300)
            }
        }

        button("查看最近耗时与执行诊断") {
            val log = getSharedPreferences("bagent_assistant_diagnostics", MODE_PRIVATE).getString("recent", "暂无记录").orEmpty()
            android.app.AlertDialog.Builder(this).setTitle("模型：Qwen3-VL-32B-Instruct")
                .setMessage(log).setPositiveButton("复制") { _, _ ->
                    (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("智能助手诊断", log))
                }.setNegativeButton("关闭", null).show()
        }

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, 32, 0, 8)
        }
        layout.addView(statusText)
        layout.addView(Button(this).apply {
            text = "刷新状态"
            setOnClickListener { refreshStatus() }
        })

        layout.addView(TextView(this).apply {
            text = "\n提示：华为/鸿蒙手机请务必在「设置→应用→启动管理」中，把智能助手设为「手动管理」，并打开「自启动」「关联启动」「后台活动」三个开关，否则系统会杀掉无障碍服务，导致预测功能失效。"
            textSize = 13f
            setTextColor(0xFFCC0000.toInt())
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshStatus()
    }

    override fun onStart() { super.onStart();isVisible=true }
    override fun onStop() { isVisible=false;super.onStop() }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val accessOn = isAccessibilityOn()
        val serviceRunning = AssistantAccessService.instance != null
        val captureReady = AssistantAccessService.instance?.hasScreenCapture() == true
        val overlayReady = Settings.canDrawOverlays(this) && FloatingService.instance?.isIconShowing() == true
        statusText?.text = buildString {
            append("【当前状态】\n")
            append("模型配置：${if(AssistantFeature.isConfigured()) "已配置" else "未配置，请由主程序配置"}\n")
            append("无障碍服务：${if (accessOn) "已开启" else "未开启"}\n")
            append("后台服务：${if (serviceRunning) "运行中" else "未运行"}\n")
            append("录屏截图：${if (captureReady) "已就绪" else "未授权"}\n\n")
            append("悬浮图标：${if (overlayReady) "已启动" else "未启动，请完成第 3、5 步"}\n\n")
            append(if (AssistantFeature.isConfigured() && accessOn && serviceRunning && captureReady && overlayReady) "✅ 一切就绪，可点击悬浮图标预测下一步" else "⚠️ 请先完成模型配置和上面未开启的步骤")
        }
    }

    private fun isAccessibilityOn(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == AssistantAccessService::class.java.name }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val ready = AssistantAccessService.instance?.initScreenCapture(resultCode, data) == true
                Toast.makeText(this, if (ready) "录屏截图已就绪" else "录屏未就绪，请先确认无障碍服务连接后重新授权", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "录屏授权被拒绝，无法截图", Toast.LENGTH_SHORT).show()
            }
            refreshStatus()
        }
    }
}
