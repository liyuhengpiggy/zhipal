package com.bagent.assistant

/** A delayed confirmation must never execute an indefinitely old proposal. */
object ConfirmationPolicy {
    fun isFresh(createdAt: Long, now: Long): Boolean =
        now >= createdAt && now - createdAt <= 60_000L
}
