package com.bagent.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * 三连击后弹出的确认窗口：展示预测的下一步操作，用户确认后执行，取消则不做。
 */
class ConfirmDialogActivity : Activity() {
    companion object {
        const val EXTRA_DESCRIPTION = "extra_description"
        const val EXTRA_REQUEST_ID = "request_id"
    }

    private var accepted = false
    private var delivered = false
    private val requestId: Long get() = intent.getLongExtra(EXTRA_REQUEST_ID, -1)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    override fun onStop() {
        super.onStop()
        if (isFinishing && !delivered) {
            delivered = true
            if (accepted) AssistantAccessService.instance?.onUserConfirmNextStep(requestId)
            else AssistantAccessService.instance?.onUserRejectNextStep(requestId)
        }
    }

    override fun onDestroy() {
        if (!delivered && !isChangingConfigurations) {
            delivered = true
            AssistantAccessService.instance?.onUserRejectNextStep(requestId)
        }
        super.onDestroy()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        // 以对话框样式展示
        val win = window
        win.setGravity(Gravity.CENTER)
        val lp = WindowManager.LayoutParams().apply {
            width = (resources.displayMetrics.widthPixels * 0.88).toInt()
            height = WindowManager.LayoutParams.WRAP_CONTENT
        }
        win.setLayout(lp.width, lp.height)
        win.setBackgroundDrawableResource(android.R.color.transparent)
        setFinishOnTouchOutside(false)

        val desc = intent.getStringExtra(EXTRA_DESCRIPTION) ?: "预测到下一步操作"

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            val bg = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 32f
                setColor(0xFFFFFFFF.toInt())
            }
            background = bg
        }
        layout.addView(TextView(this).apply {
            text = "预测的下一步操作"
            textSize = 18f
            setTextColor(0xFF111111.toInt())
        })
        layout.addView(TextView(this).apply {
            text = desc
            textSize = 16f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 24, 0, 32)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        row.addView(Button(this).apply {
            text = "取消"
            setOnClickListener { finish() }
        })
        val confirm = Button(this).apply {
            text = "执行"
            setOnClickListener { isEnabled = false; accepted = true; finish() }
        }
        val rowLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(confirm, rowLp)
        layout.addView(row)
        setContentView(layout)
    }
}
