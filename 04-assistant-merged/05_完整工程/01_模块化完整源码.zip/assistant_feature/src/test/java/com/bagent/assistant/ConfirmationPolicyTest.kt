package com.bagent.assistant

import org.junit.Assert.*
import org.junit.Test

class ConfirmationPolicyTest {
    @Test fun acceptsImmediatelyAndAtExpiryBoundary() {
        assertTrue(ConfirmationPolicy.isFresh(12_000, 12_000))
        assertTrue(ConfirmationPolicy.isFresh(12_000, 72_000))
    }
    @Test fun rejectsStaleConfirmation() {
        assertFalse(ConfirmationPolicy.isFresh(12_000, 72_001))
    }
    @Test fun rejectsClockRollbackOrDifferentBoot() {
        assertFalse(ConfirmationPolicy.isFresh(12_000, 11_999))
    }
}
