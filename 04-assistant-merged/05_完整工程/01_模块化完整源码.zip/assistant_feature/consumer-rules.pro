# Android entry points are manifest-referenced; explicit names aid host upgrades and diagnostics.
-keepnames class com.bagent.assistant.AssistantAccessService
-keepnames class com.bagent.assistant.AssistantSetupActivity
-keepnames class com.bagent.assistant.FloatingService
