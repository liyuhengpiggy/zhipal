plugins { id("com.android.library"); id("org.jetbrains.kotlin.android");  id("maven-publish") }
group = "com.bagent"
version = "1.3.0"
android {
 namespace = "com.bagent.assistant"
 compileSdk = 34
 defaultConfig { minSdk = 30; consumerProguardFiles("consumer-rules.pro") }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
 publishing { singleVariant("release") { withSourcesJar() } }
}
dependencies {
 api(project(":android_library"))
 implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
 testImplementation("junit:junit:4.13.2")
}
afterEvaluate {
 publishing {
  publications { register<MavenPublication>("release") {
   groupId = "com.bagent"; artifactId = "assistant-feature"; version = "1.3.0"
   from(components["release"])
  } }
  repositories { maven { name = "handoff"; url = uri(rootProject.layout.projectDirectory.dir("dist/maven")) } }
 }
}
