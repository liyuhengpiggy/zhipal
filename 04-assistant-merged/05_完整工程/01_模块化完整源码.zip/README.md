# 智能助手模块化 SDK 1.3.0

主入口为 assistant_feature 中的 com.bagent.assistant.AssistantFeature。

先阅读 docs/01_APK合并接入手册.md。旧 API_CONTRACT、APK_INTEGRATION 和历史版本 README 已归档到 docs/history，不要与新 feature 同时启动两套执行流程。

模块：model_client（模型访问）、integration（核心协议）、android_library（Android 核心）、assistant_feature（可接入功能）、sample_app（薄宿主）。examples/binary_host 是独立 Maven 二进制宿主，使用不同 applicationId。

构建需要 JDK17、Gradle8.7、SDK Platform34/Build Tools34.0.0。配置 ANDROID_HOME 或 local.properties。源码未附带本机 Key；复制 model.local.properties.example 为 model.local.properties 并填写 api.key 后构建示例。SDK 本身不依赖该文件；正式宿主通过 Application.onCreate 的 AssistantFeature.configure 配置。

```powershell
gradle :integration:test :model_client:testDebugUnitTest :android_library:testDebugUnitTest :assistant_feature:testDebugUnitTest :sample_app:assembleDebug :sample_app:assembleDebugAndroidTest :sample_app:lintDebug
gradle :model_client:publish :integration:publish :android_library:publish :assistant_feature:publish
gradle -p examples/binary_host :app:assembleDebug :app:assembleRelease
```

dist/maven 保留本次已构建发布物，便于直接验证二进制接入；它不是完整离线 Gradle/Android 工具链。sample_app 的 SDK 服务组件已更名，升级后需重新启用无障碍和录屏；详见手册。

原始桌面 ZIP 与后续交接 ZIP 在外层交付目录 01_原始模型源码中按原字节保留。当前模型仍通过 SiliconFlow 调用 Qwen/Qwen3-VL-32B-Instruct，没有本地 32B 权重。sources/AAR、二进制宿主和模板不含真实 Key；示例 APK 是现有测试配置构建物。

实际验证：46 项本地测试通过，源码宿主与不同包名 Maven 宿主 debug/release(minify) 构建成功；没有最终主工程和已连接设备，不能把上述构建结果当作目标软件的真机验收。
