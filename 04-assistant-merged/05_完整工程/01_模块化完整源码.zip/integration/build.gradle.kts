plugins { id("org.jetbrains.kotlin.jvm"); id("maven-publish") }
group="com.bagent"
version="1.3.0"
kotlin { jvmToolchain(17) }
java { withSourcesJar() }
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3"); testImplementation("junit:junit:4.13.2"); testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3") }
publishing {
 publications { register<MavenPublication>("java") { from(components["java"]); groupId="com.bagent";artifactId="integration";version="1.3.0" } }
 repositories { maven { name="handoff";url=uri(rootProject.layout.projectDirectory.dir("dist/maven")) } }
}
