package com.bagent.integration

import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.Assert.*
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BAssistEngineTest {
    private class Port(private val scope: CoroutineScope) : SingleStepPort {
        var page = "page1"; var clicks = 0; var observes = 0; var reflected = 0
        var gate: CompletableDeferred<Unit>? = null
        val live = mutableSetOf<String>()
        override suspend fun observe(): Observation { observes++; return Observation("s$observes", page, "test.app", 1).also { live.add(it.token) } }
        override suspend fun suggest(goal: String, history: List<RecentEvent>, screen: Observation): Suggestion { gate?.await(); return Suggestion("点击实际控件", "one-action", "target") }
        override fun dispatchOnce(screen: Observation, suggestion: Suggestion): Deferred<Boolean> { clicks++; return CompletableDeferred(true) }
        override suspend fun reflect(before: Observation, after: Observation, suggestion: Suggestion, goal: String): String { reflected++; return "A:verified" }
        override fun release(screen: Observation) { live.remove(screen.token) }
    }
    private class Listener : AssistListener {
        val prompts = mutableListOf<AssistPrompt>(); val events = mutableListOf<AssistEvent>()
        override fun onPrompt(prompt: AssistPrompt) { prompts.add(prompt) }
        override fun onEvent(event: AssistEvent) { events.add(event) }
    }
    private fun TestScope.setup(): Triple<BAssistEngine, Port, Listener> {
        val port = Port(backgroundScope); val listener = Listener()
        return Triple(BAssistEngine(port, backgroundScope, listener, { testScheduler.currentTime }, 5000), port, listener).also { it.first.startObserving() }
    }
    private fun TestScope.propose(e: BAssistEngine) {
        e.onBHelpRequested("t"); val p = e.currentPrompt!!
        e.onBSpeechResult("t", p.promptId, "B", "我想和女儿视频"); runCurrent()
        assertEquals(PromptKind.ACTION, e.currentPrompt!!.kind)
    }
    @Test fun repeatedClicksTriggerWithoutInferringGoal() = runTest {
        val (e,p,l)=setup()
        repeat(3) { e.onEvent(RecentEvent(it*1000L,RecentEvent.Kind.CLICK,"same","button")) }
        assertEquals(1,l.prompts.size); assertEquals(PromptKind.GOAL,l.prompts.single().kind); assertEquals(0,p.clicks)
    }
    @Test fun readingAndWaitingNeverTrigger() {
        val d=DifficultyDetector(); repeat(20) { assertNull(d.add(RecentEvent(it*1000L,RecentEvent.Kind.OTHER,"same"))) }
    }
    @Test fun realProgressPreventsRepeatedClickRule() {
        val d=DifficultyDetector(); repeat(3) { assertNull(d.add(RecentEvent(it*1000L,RecentEvent.Kind.CLICK,"page$it","sameButton"))) }
    }
    @Test fun pagePingPongRequiresSixTransitions() {
        val d=DifficultyDetector(); repeat(5) { assertNull(d.add(RecentEvent(it*1000L,RecentEvent.Kind.PAGE,"p${it%2}"))) }
        assertEquals("page_ping_pong",d.add(RecentEvent(5000,RecentEvent.Kind.PAGE,"p1")))
    }
    @Test fun confirmationDispatchesExactlyOneThenStops() = runTest {
        val (e,p,l)=setup(); propose(e); val q=e.currentPrompt!!
        e.onBSpeechResult("t",q.promptId,"B","对"); runCurrent(); advanceTimeBy(900);runCurrent()
        assertEquals(1,p.clicks); assertEquals(1,p.reflected); assertNull(e.currentPrompt); assertTrue(p.live.isEmpty())
        assertTrue(l.events.any { it.type=="stopped" && it.detail=="single_step_complete" })
        advanceTimeBy(10000);runCurrent();assertEquals(1,p.clicks)
    }
    @Test fun duplicatePromptCannotRepeatDispatch() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!
        repeat(4) { e.onBSpeechResult("t",q.promptId,"B","对") };runCurrent();assertEquals(1,p.clicks)
    }
    @Test fun refusalNeverDispatches() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!;e.onBSpeechResult("t",q.promptId,"B","不用了");runCurrent();assertEquals(0,p.clicks);assertTrue(p.live.isEmpty())
    }
    @Test fun pageChangeInvalidatesCandidate() = runTest {
        val (e,p,l)=setup();propose(e);p.page="different";val q=e.currentPrompt!!;e.onBSpeechResult("t",q.promptId,"B","对");runCurrent()
        assertEquals(0,p.clicks);assertTrue(l.events.any { it.detail=="stale_page" });assertTrue(p.live.isEmpty())
    }
    @Test fun aPreemptsPendingPrompt() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!;e.onATaskStarted();e.onBSpeechResult("t",q.promptId,"B","对");runCurrent();assertEquals(0,p.clicks)
        e.onATaskFinished();e.onBSpeechResult("t",q.promptId,"B","对");runCurrent();assertEquals(0,p.clicks)
    }
    @Test fun aCancelsOutstandingModelAnalysis() = runTest {
        val (e,p,_)=setup();p.gate=CompletableDeferred();e.onBHelpRequested("t");val q=e.currentPrompt!!
        e.onBSpeechResult("t",q.promptId,"B","我想打开联系人");runCurrent();e.onATaskStarted();p.gate!!.complete(Unit);runCurrent()
        assertNull(e.currentPrompt);assertEquals(0,p.clicks);assertTrue(p.live.isEmpty())
    }
    @Test fun wrongTaskPromptSourceAndUnknownSpeechNeverDispatch() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!
        e.onBSpeechResult("bad",q.promptId,"B","对");e.onBSpeechResult("t","bad","B","对");e.onBSpeechResult("t",q.promptId,"A","对");e.onBSpeechResult("t",q.promptId,"B","嗯嗯");runCurrent();assertEquals(0,p.clicks)
    }
    @Test fun timeoutInvalidatesAndReleases() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!;advanceTimeBy(5001);runCurrent();e.onBSpeechResult("t",q.promptId,"B","对");runCurrent();assertEquals(0,p.clicks);assertTrue(p.live.isEmpty())
    }
    @Test fun notThisAsksForClarificationAndNeverExecutes() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!;e.onBSpeechResult("t",q.promptId,"B","不是这个");runCurrent()
        assertEquals(PromptKind.GOAL,e.currentPrompt!!.kind);assertNotEquals(q.promptId,e.currentPrompt!!.promptId);assertEquals(0,p.clicks)
    }
    @Test fun yesWithoutGoalCannotExecute() = runTest {
        val (e,p,_)=setup();e.onBHelpRequested("t");val q=e.currentPrompt!!;e.onBSpeechResult("t",q.promptId,"B","对");runCurrent();assertEquals(0,p.clicks);assertEquals(0,p.observes)
    }
    @Test fun aCancelsConfirmationBeforeCoroutineStartsAndReleasesFrame() = runTest {
        val (e,p,_)=setup();propose(e);val q=e.currentPrompt!!
        e.onBSpeechResult("t",q.promptId,"B","对");e.onATaskStarted();runCurrent()
        assertEquals(0,p.clicks);assertTrue(p.live.isEmpty())
    }
}
