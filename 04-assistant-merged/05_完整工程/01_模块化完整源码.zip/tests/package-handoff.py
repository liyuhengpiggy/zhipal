from pathlib import Path
import json,hashlib,zipfile,sys
root=Path(__file__).resolve().parents[1]
excluded={'.git','.gradle','.idea','build','__pycache__','last-device-evidence'}
def selected(p):
    rel=p.relative_to(root)
    return p.is_file() and not any(x in excluded for x in rel.parts) and p.name not in {'local.properties','model.local.properties','last-device-run.log','HANDOFF_MANIFEST.json'} and not p.name.endswith(('.zip','.pyc'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for entry in json.loads((root/'upstream-files.json').read_text(encoding='utf-8')):
    assert digest(root/entry['local'])==entry['local_sha256'],entry['local']
files=sorted(p for p in root.rglob('*') if selected(p))
manifest={'format':1,'algorithm':'SHA256','files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]}
mp=root/'HANDOFF_MANIFEST.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files.append(mp)
dest=Path(sys.argv[1]) if len(sys.argv)>1 else root.parent/'b_agent_android_handoff.zip'
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files: z.write(p,'b_agent_handoff/'+p.relative_to(root).as_posix())
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    assert all(x.startswith('b_agent_handoff/') for x in z.namelist())
sha=digest(dest)
dest.with_suffix('.zip.sha256.txt').write_text(sha+'  '+dest.name+'\n',encoding='ascii')
print(json.dumps({'zip':str(dest),'files':len(files),'bytes':dest.stat().st_size,'sha256':sha,'upstream_hashes':'PASS'},indent=2))
