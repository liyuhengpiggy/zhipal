param(
 [Parameter(Mandatory=$true)][string]$LlamaServer,
 [Parameter(Mandatory=$true)][string]$ModelFile,
 [Parameter(Mandatory=$true)][string]$ProjectorFile,
 [int]$Port = 8087
)
$ErrorActionPreference = "Stop"
foreach ($file in @($LlamaServer,$ModelFile,$ProjectorFile)) {
 if (!(Test-Path -LiteralPath $file)) { throw "Missing file: $file" }
}
# Existing llama.cpp binary, no new application backend. Foreground for visible test logs.
& $LlamaServer -m $ModelFile --mmproj $ProjectorFile --host 127.0.0.1 --port $Port --alias qwen3-vl-2b -ngl 99 -c 12288 --parallel 1 --jinja --reasoning-budget 0
if ($LASTEXITCODE) { throw "llama-server exited with error" }
