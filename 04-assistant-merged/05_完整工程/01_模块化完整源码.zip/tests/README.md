# 测试入口

- JVM源码：integration/src/test/kotlin/com/bagent/integration/BAssistEngineTest.kt，15项，确定性的端口测试替身，仅验证状态/规则，不冒充视觉。
- Android源码：sample_app/src/androidTest/java/com/bagent/sample/DeviceAcceptanceTest.kt，5项；真实Android View、AccessibilityEvent、截图与移植手势。
- realModelScreenshotConfirmationOneGestureAndStop 使用原 OpenAiCompatibleClient 调真实视觉接口；采集prompt、PNG和回复。若没有endpoint，本项明确失败，不跳过或伪造模型。
- refusal/changedPage/A-preemption 的模型为显式mock，目标坐标来自真实控件；真实截图和防护/页面切换仍在模拟器上验证。automaticDifficulty没有模型调用。
- core单元测试包含重复编号/超时/错来源/取消竞态；设备真实模型测试连续三次提交同prompt的“对”，实际计数仍为1，未点击下一页视频按钮。

PowerShell脚本见run-device-tests.ps1。要求启动并解锁模拟器/连接测试机、ANDROID_HOME、JDK17及Gradle。脚本会仅在测试设备上启用示例无障碍服务；它不是主APK的授权流程，勿对私人生产设备无准备地运行。

使用现成llama.cpp测试时运行start-local-model.ps1，再通过adb reverse映射相同端口。真实模型文件和下载校验见evidence/model-provenance.json。公网API也可通过脚本Endpoint/Model输入；本脚本不接收生产密钥，带凭据的生产模型请由主APK安全配置接入。

测试页面fixture_only=true隐藏输入/调试面板，保持普通联系人页面；ASR转写直接经Main线程进入同一个公开BAssist接口，如真实主APK硬件语音的接入方式。屏幕上的调试文本框会改变画面，不适合测试确认时的画面一致性。

证据中第一轮真实模型失败保留在diagnostics/initial-vision-failure：模型受调试面板干扰并返回未列出的坐标；模块拒绝且未执行。后续改用普通联系人场景、动态列出真实合法点击对象。没有将失败输出替换为固定正确JSON。

重新打包：安装Python 3后执行 `python tests/package-handoff.py`，默认在工程父目录生成 b_agent_android_handoff.zip 与SHA256文本。脚本排除构建缓存、本地配置和模型文件，核对移植文件哈希，并生成 HANDOFF_MANIFEST.json。此清单覆盖交付文件，清单自身除外。
