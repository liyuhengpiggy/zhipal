# No reflection-based action execution; no custom keep rules required.
