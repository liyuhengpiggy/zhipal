package com.bagent.android

import org.junit.Assert.*
import org.junit.Test

class ExecutionGuardTest {
    private val title = ExecutionGuard.Element("title|联系人|Text", "联系人", 100, 50, 200, 40, clickable=false)
    private val target = ExecutionGuard.Element("video|视频通话|Button", "视频通话", 200, 400, 160, 60)
    private val clock = ExecutionGuard.Element("clock|12:00|Text", "12:00", 100, 10, 50, 20, clickable=false)
    private val before = listOf(title,target,clock)
    private fun select(now: List<ExecutionGuard.Element>, pkg: String = "app") =
        ExecutionGuard.select("app",pkg,before,now,target.key,8)
    private fun rejected(block: () -> Unit) { try { block(); fail("must reject") } catch (_: IllegalArgumentException) {} }

    @Test fun ignoresTreeOrderAndClockTick() {
        assertEquals(target,select(listOf(clock.copy(identity="clock|12:01|Text",label="12:01"),target,title)))
    }
    @Test fun ignoresUnlabelledLayoutAndUnrelatedEnabledState() {
        assertEquals(target,select(before + ExecutionGuard.Element("layout","",0,0,999,999,clickable=false)))
        assertEquals(target,select(listOf(title.copy(enabled=false),target,clock)))
    }
    @Test fun allowsSmallTargetLayoutJitter() { assertEquals(205,select(listOf(title,target.copy(x=205),clock)).x) }
    @Test fun rejectsDifferentApplication() { rejected { select(before,"other") } }
    @Test fun rejectsDifferentPageWithSameActionButton() {
        rejected { select(listOf(title.copy(identity="title|付款|Text",label="付款"),target,clock)) }
    }
    @Test fun rejectsTargetTextOrIdentityChange() { rejected { select(listOf(title,target.copy(identity="video|转账|Button"),clock)) } }
    @Test fun rejectsMissingTarget() { rejected { select(listOf(title,clock)) } }
    @Test fun rejectsDisabledTarget() { rejected { select(listOf(title,target.copy(enabled=false),clock)) } }
    @Test fun rejectsPasswordTarget() { rejected { select(listOf(title,target.copy(password=true),clock)) } }
    @Test fun rejectsLargeMovementOrScroll() { rejected { select(listOf(title,target.copy(y=450),clock)) } }
    @Test fun rejectsDuplicateAmbiguousTargets() { rejected { select(before+target) } }
    @Test fun rejectsChangedToggleState() { rejected { select(listOf(title,target.copy(checked=true),clock)) } }
}
