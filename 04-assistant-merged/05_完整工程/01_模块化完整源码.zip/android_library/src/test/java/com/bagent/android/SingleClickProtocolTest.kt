package com.bagent.android

import org.junit.Assert.*
import org.junit.Test

class SingleClickProtocolTest {
    @Test fun acceptsOnlyAllowedIntegerId() { assertEquals(3,SingleClickProtocol.parse("{\"target_id\":3}",setOf(1,3))) }
    @Test fun acceptsFencedJson() { assertEquals(3,SingleClickProtocol.parse("```json\n{\"target_id\":3}\n```",setOf(3))) }
    @Test fun uncertaintyDoesNotProduceAnAction() { assertNull(SingleClickProtocol.parse("{\"target_id\":null}",setOf(1))) }
    private fun reject(value: String) { try { SingleClickProtocol.parse(value,setOf(1));fail("must reject") } catch (_: Exception) {} }
    @Test fun rejectsUnlistedId() = reject("{\"target_id\":2}")
    @Test fun rejectsTextAndFractionalIds() { reject("{\"target_id\":\"1\"}");reject("{\"target_id\":1.5}") }
    @Test fun rejectsCoordinatesOrMultipleActions() {
        reject("{\"target_id\":1,\"coordinate\":[5,5]}")
        reject("{\"target_id\":1}{\"target_id\":1}")
        reject("[{\"target_id\":1}]")
    }
}
