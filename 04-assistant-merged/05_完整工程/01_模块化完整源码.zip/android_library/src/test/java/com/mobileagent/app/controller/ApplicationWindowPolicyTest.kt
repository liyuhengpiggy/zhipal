package com.mobileagent.app.controller

import org.junit.Assert.*
import org.junit.Test

class ApplicationWindowPolicyTest {
    private fun w(id: Int, type: Int = 1, active: Boolean = false, focused: Boolean = false, layer: Int = 0) =
        ApplicationWindowPolicy.Candidate(id, type, active, focused, layer)

    @Test fun touchedOverlayDoesNotReplaceUnderlyingApplication() {
        assertEquals(10, ApplicationWindowPolicy.select(listOf(w(10, focused=true), w(20, type=3, active=true, layer=99))))
    }
    @Test fun keyboardAndAccessibilityPanelAreNotTargetApplications() {
        assertEquals(10, ApplicationWindowPolicy.select(listOf(w(10), w(20,type=2,focused=true), w(30,type=4,active=true))))
    }
    @Test fun currentAppWinsOverBackgroundApp() {
        assertEquals(10, ApplicationWindowPolicy.select(listOf(w(20,layer=100), w(10,active=true,focused=true))))
    }
    @Test fun ownSetupActivityRemainsTheForegroundApp() {
        // Package names must not be used to silently choose an old background application.
        assertEquals(20, ApplicationWindowPolicy.select(listOf(w(10), w(20,active=true))))
    }
    @Test fun topApplicationUsedWhenOemOmitsFocusFlags() {
        assertEquals(20, ApplicationWindowPolicy.select(listOf(w(10,layer=1), w(20,layer=2))))
    }
    @Test fun missingApplicationDoesNotSelectSystemWindow() {
        assertNull(ApplicationWindowPolicy.select(listOf(w(20,type=3,active=true))))
        assertNull(ApplicationWindowPolicy.select(emptyList()))
    }
}
