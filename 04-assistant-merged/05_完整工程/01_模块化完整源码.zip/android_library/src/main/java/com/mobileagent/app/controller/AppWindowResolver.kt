package com.mobileagent.app.controller

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo

/** The touched window may be our bubble, toast or panel, rather than the application. */
object AppWindowResolver {
    @Suppress("DEPRECATION")
    fun obtainRoot(service: AccessibilityService): AccessibilityNodeInfo? {
        val windows = service.windows
        try {
            val selected = ApplicationWindowPolicy.select(windows.map {
                ApplicationWindowPolicy.Candidate(it.id, it.type, it.isActive, it.isFocused, it.layer)
            })
            if (selected != null) return windows.first { it.id == selected }.root
            // Some OEMs do not expose interactive windows. Do not substitute another app
            // if a selected application exists but has no readable root.
            return service.rootInActiveWindow
        } finally { windows.forEach { it.recycle() } }
    }
}
