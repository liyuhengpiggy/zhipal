package com.bagent.android

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import com.bagent.integration.*
import com.mobileagent.app.agent.*
import com.mobileagent.app.api.*
import com.mobileagent.app.controller.*
import com.mobileagent.app.util.JsonActionParser
import kotlinx.coroutines.*
import java.security.MessageDigest
import java.util.UUID

/** Calls host screenshot provider first; no MediaProjection authorization and no new service. */
class AndroidAssistPort(
    private val service: AccessibilityService,
    private val capture: suspend () -> Bitmap?,
    private val api: VlmApiClient,
    private val scope: CoroutineScope
) : SingleStepPort {
    private data class Frame(val image: Bitmap, val elements: List<UiElement>)
    private val frames = mutableMapOf<String, Frame>()
    private val actions = AccessibilityActions(service)
    var lastDispatchMode: String = "none"
        private set
    var lastBeforeDispatchSignature: String = ""
        private set
    override suspend fun observe(): Observation {
        assertMain()
        val before = identity()
        val bitmap = capture() ?: error("screenshot_unavailable")
        try {
            val elements = UiElementDetector.detectElements(service)
            val after = identity()
            // 放宽校验：HarmonyOS 上 MediaProjection 截图耗时较长，截图期间页面任何微小变化
            // （状态栏刷新、动画等）都会导致控件树签名不一致。这里不再强求前后完全一致，
            // 只要页面身份（包名+窗口）没变就继续，用截图后的控件树（与截图时刻最接近）。
            require(before == after) { "page_changed_during_capture" }
            require(elements.isNotEmpty()) { "empty_accessibility_tree" }
            // Compare accessible content and geometry. Raw pixels include clocks, cursor blink
            // and videos and would reject an unchanged target on almost every confirmation.
            val fingerprint = sha(after.toString() + elementSignature(elements))
            val token = UUID.randomUUID().toString()
            frames[token] = Frame(bitmap, elements)
            return Observation(token, fingerprint, after.first, after.second)
        } catch (e: Throwable) { bitmap.recycle(); throw e }
    }
    override suspend fun suggest(goal: String, history: List<RecentEvent>, screen: Observation): Suggestion {
        assertMain()
        val frame = frames[screen.token] ?: error("released_frame")
        val options = frame.elements.filter { it.isClickable && it.enabled && !it.password &&
            it.bounds.centerX() in 0 until frame.image.width && it.bounds.centerY() in 0 until frame.image.height }
        require(options.isNotEmpty()) { "当前页面没有可点击控件" }
        val choices = options.joinToString("\n") {
            "id=${it.index} label=${displayLabel(it, frame.elements).take(80)} bounds=${it.bounds}"
        }
        val recent = history.filter { it.kind == RecentEvent.Kind.CLICK }.takeLast(5)
            .joinToString("\n") { it.control.take(160) }
        val prompt = "目标：$goal\n原屏幕尺寸：${frame.image.width}x${frame.image.height}\n最近点击（只作线索）：\n$recent\n当前可选控件（bounds为原屏幕像素，仅用于定位）：\n$choices\n只返回target_id的JSON，不要解释。"
        // A single short request. The ID is mapped to original device coordinates locally.
        val response = api.predictWithImages(SingleClickProtocol.SYSTEM, prompt, listOf(frame.image)).getOrThrow()
        val id = SingleClickProtocol.parse(response, options.map { it.index }.toSet())
            ?: error("暂时无法确定下一步操作，请在目标应用中再操作一次后重试")
        val selected = options.single { it.index == id }
        val label = displayLabel(selected, frame.elements)
        require(label.isNotBlank()) { "目标缺少可识别名称，请重新预测" }
        return Suggestion("点击“$label”", """{"action":"click","coordinate":[${selected.bounds.centerX()},${selected.bounds.centerY()}]}""", key(selected))
    }
    override fun dispatchOnce(screen: Observation, suggestion: Suggestion): Deferred<Boolean> {
        assertMain()
        val frame = frames[screen.token] ?: error("released_frame")
        val action = JsonActionParser.parseAction(suggestion.actionJson)
        require(action is AgentAction.Click) { "只支持用户确认的一次点击" }
        val original = frame.elements.singleOrNull { key(it) == suggestion.targetKey } ?: error("原目标失效")
        require(action.x == original.bounds.centerX() && action.y == original.bounds.centerY()) { "点击内容与确认目标不一致" }
        val current = UiElementDetector.detectElements(service)
        lastDispatchMode = "none"
        val selected = validateTarget(screen, frame.elements, current, suggestion)
        lastBeforeDispatchSignature = signature(current)
        lastDispatchMode = "native"
        if (UiElementDetector.clickNative(service, selected, screen.packageName)) {
            return CompletableDeferred(true)
        }
        // Native ACTION_CLICK was explicitly rejected. Revalidate before ONE gesture fallback.
        val reread = UiElementDetector.detectElements(service)
        val fallback = validateTarget(screen, frame.elements, reread, suggestion)
        lastDispatchMode = "gesture"
        return scope.async(start = CoroutineStart.UNDISPATCHED) {
            actions.performTap(fallback.bounds.centerX().toFloat(), fallback.bounds.centerY().toFloat())
        }
    }
    private fun validateTarget(screen: Observation, before: List<UiElement>, current: List<UiElement>, suggestion: Suggestion): UiElement {
        val selected = ExecutionGuard.select(screen.packageName, identity().first,
            before.map(::snapshot), current.map(::snapshot), suggestion.targetKey,
            (8 * service.resources.displayMetrics.density).toInt())
        return current.single { snapshot(it).key == selected.key }
    }
    override suspend fun reflect(before: Observation, after: Observation, suggestion: Suggestion, goal: String): String {
        val info = InfoPool(instruction = goal, lastAction = JsonActionParser.extractActionMap(suggestion.actionJson), lastSummary = suggestion.description)
        val reflector = ActionReflector()
        val images = listOf(frames.getValue(before.token).image, frames.getValue(after.token).image)
        val result = api.predictWithImages(null, reflector.getPrompt(info), images).getOrThrow()
        reflector.parseResponse(result, info)
        return "${reflector.lastOutcome}:${reflector.lastErrorDescription}"
    }
    override fun release(screen: Observation) { frames.remove(screen.token)?.image?.recycle() }
    private fun displayLabel(element: UiElement, elements: List<UiElement>): String =
        element.text.ifBlank { element.contentDescription }.ifBlank {
            elements.asSequence().filter { it !== element && !it.password && !it.isClickable && element.bounds.contains(it.bounds) }
                .map { it.text.ifBlank { it.contentDescription } }.filter { it.isNotBlank() }.distinct().take(3).joinToString(" ")
        }.ifBlank { element.viewId }
    fun pageSignature(): String = signature(UiElementDetector.detectElements(service))
    private fun signature(elements: List<UiElement>) = sha(identity().first + ExecutionGuard.anchors(elements.map(::snapshot)).sorted().joinToString("\n") +
        elements.filter { it.isClickable }.map { "${key(it)}|${it.enabled}" }.sorted().joinToString("\n"))
    private fun snapshot(el: UiElement): ExecutionGuard.Element = ExecutionGuard.Element(
        "${el.viewId}|${el.text.trim()}|${el.contentDescription.trim()}|${el.className}",
        el.text.ifBlank { el.contentDescription }.trim(), el.bounds.centerX(), el.bounds.centerY(),
        el.bounds.width(), el.bounds.height(), el.isClickable, el.enabled, el.password, el.checked, el.selected)
    private fun identity(): Pair<String, Int> {
        val node = AppWindowResolver.obtainRoot(service) ?: error("no_active_window")
        return try {
            // windowId 在 HarmonyOS 上不稳定（点击悬浮窗/MediaProjection 截图会改变活动窗口），
            // 这里固定为 0，让所有身份比较只依赖 packageName，避免误判 page_changed/window_changed。
            node.packageName.toString() to 0
        } finally { node.recycle() }
    }
    private fun key(el: UiElement) = snapshot(el).key
    private fun elementSignature(elements: List<UiElement>) = elements.map { "${key(it)}|${it.isClickable}|${it.isScrollable}|${it.enabled}|${it.password}" }.sorted().joinToString("\n")
    private fun sha(text: String) = MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun assertMain() { check(android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) { "Call B on Android Main thread" } }
}
