package com.bagent.android

/** Device-independent checks: ignore tree enumeration order and volatile clock/counter text,
 * but retain application, meaningful page content, target identity/state and location. */
object ExecutionGuard {
    data class Element(
        val identity: String, val label: String, val x: Int, val y: Int, val width: Int, val height: Int,
        val clickable: Boolean = true, val enabled: Boolean = true, val password: Boolean = false,
        val checked: Boolean = false, val selected: Boolean = false
    ) {
        val key: String get() = "$identity|$x,$y,$width,$height|$checked|$selected"
    }

    private val volatile = Regex("^[\\d\\s:：./%+−-]+$")
    fun anchors(elements: List<Element>): Set<String> = elements.asSequence()
        .filter { !it.password && it.label.isNotBlank() && !volatile.matches(it.label) }
        .map { "${it.identity}|${it.clickable}" }.toSet()

    fun select(beforePackage: String, currentPackage: String, before: List<Element>, current: List<Element>,
               targetKey: String, tolerance: Int): Element {
        require(beforePackage == currentPackage) { "目标应用已切换，请重新预测" }
        val original = before.singleOrNull { it.key == targetKey } ?: error("原目标已失效，请重新预测")
        val matches = current.filter {
            it.identity == original.identity && it.clickable && it.enabled && !it.password &&
                it.checked == original.checked && it.selected == original.selected &&
                kotlin.math.abs(it.x - original.x) <= tolerance && kotlin.math.abs(it.y - original.y) <= tolerance &&
                kotlin.math.abs(it.width - original.width) <= tolerance && kotlin.math.abs(it.height - original.height) <= tolerance
        }
        require(matches.size == 1) { "目标已移动、消失、重复或状态改变，请重新预测" }
        require(anchors(before) == anchors(current)) { "页面主要内容已变化，请重新预测" }
        return matches.single()
    }
}
