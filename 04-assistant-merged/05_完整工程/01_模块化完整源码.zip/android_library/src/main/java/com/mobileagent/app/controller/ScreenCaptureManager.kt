package com.mobileagent.app.controller

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.Image
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.delay

/** All methods and projection callbacks run on Main. One display per consent token. */
class ScreenCaptureManager(private val context: Context) {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var width = 0
    private var height = 0
    val isReady: Boolean get() = mediaProjection != null && virtualDisplay != null && imageReader != null

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() { release() }
    }

    @Suppress("DEPRECATION", "WrongConstant")
    fun initialize(projection: MediaProjection) {
        release()
        mediaProjection = projection
        projection.registerCallback(callback, Handler(Looper.getMainLooper()))
        try {
            val metrics = displayMetrics()
            width = metrics.widthPixels
            height = metrics.heightPixels
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).also { reader ->
                reader.setOnImageAvailableListener({ source ->
                    if (imageReader === source) {
                        source.acquireLatestImage()?.let { image ->
                            latestImage?.close()
                            latestImage = image
                        }
                    }
                }, Handler(Looper.getMainLooper()))
            }
            virtualDisplay = projection.createVirtualDisplay(
                "AssistantCapture", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader!!.surface, null, null
            )
        } catch (e: Exception) {
            release()
            throw e
        }
    }

    private fun displayMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    suspend fun capture(): Bitmap? {
        check(isReady) { "录屏已停止，请回到智能助手重新授权屏幕截图" }
        val metrics = displayMetrics()
        check(metrics.widthPixels == width && metrics.heightPixels == height) {
            "屏幕方向或分辨率已变化，请重新授权屏幕截图"
        }
        val reader = imageReader ?: return null
        // Drain continuously via the listener, retaining one image. A static display may
        // produce no further frame: discarding its last image would cause false timeouts.
        delay(100)
        val deadline = SystemClock.elapsedRealtime() + 1_500
        while (SystemClock.elapsedRealtime() < deadline) {
            check(isReady && imageReader === reader) { "录屏已停止，请重新授权" }
            val image = latestImage
            if (image == null) { delay(80); continue }
                val plane = image.planes[0]
                val paddedWidth = plane.rowStride / plane.pixelStride
                val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
                try {
                    padded.copyPixelsFromBuffer(plane.buffer.duplicate().apply { rewind() })
                    if (paddedWidth == width) return padded
                    return Bitmap.createBitmap(padded, 0, 0, width, height).also { padded.recycle() }
                } catch (e: Throwable) {
                    padded.recycle()
                    throw e
                }
        }
        error("未收到新的录屏画面，请保持屏幕亮起并重新授权截图")
    }

    fun release() {
        val projection = mediaProjection
        mediaProjection = null
        virtualDisplay?.release()
        virtualDisplay = null
        latestImage?.close()
        latestImage = null
        imageReader?.close()
        imageReader = null
        projection?.unregisterCallback(callback)
        projection?.stop()
    }
}
