package com.mobileagent.app.controller

import android.graphics.*
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.AccessibilityService

data class UiElement(
    val index: Int,
    val text: String,
    val className: String,
    val bounds: Rect,
    val isClickable: Boolean,
    val isScrollable: Boolean,
    val contentDescription: String,
    val viewId: String = "",
    val enabled: Boolean = true,
    val password: Boolean = false,
    val checked: Boolean = false,
    val selected: Boolean = false
)

object UiElementDetector {

    /** Never fall back after an accepted native click: that would risk a second action. */
    @Suppress("DEPRECATION")
    fun clickNative(service: AccessibilityService, element: UiElement, packageName: String): Boolean {
        val root = AppWindowResolver.obtainRoot(service) ?: error("无法读取目标应用")
        val matches = mutableListOf<AccessibilityNodeInfo>()
        fun visit(node: AccessibilityNodeInfo) {
            val bounds = Rect().also { node.getBoundsInScreen(it) }
            if (node.isVisibleToUser && node.isClickable && node.isEnabled && !node.isPassword &&
                node.viewIdResourceName.orEmpty() == element.viewId && node.className?.toString().orEmpty() == element.className &&
                node.text?.toString()?.take(50).orEmpty() == element.text &&
                node.contentDescription?.toString()?.take(50).orEmpty() == element.contentDescription && bounds == element.bounds) {
                matches.add(AccessibilityNodeInfo.obtain(node))
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try { visit(child) } finally { child.recycle() }
            }
        }
        return try {
            require(root.packageName?.toString() == packageName) { "目标应用已切换，请重新预测" }
            visit(root)
            require(matches.size == 1) { "点击前目标已变化，请重新预测" }
            matches.single().performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } finally { root.recycle(); matches.forEach { it.recycle() } }
    }

    fun detectElements(service: AccessibilityService): List<UiElement> {
        val root = AppWindowResolver.obtainRoot(service) ?: return emptyList()
        val elements = mutableListOf<UiElement>()
        var index = 0
        try { traverseNode(root, elements, index = { index++ }) } finally { root.recycle() }
        return elements
    }

    fun annotateScreenshot(bitmap: Bitmap, elements: List<UiElement>): Bitmap {
        val annotated = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(annotated)

        val boxPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }

        val labelBgPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
        }

        val labelTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
        }

        for (el in elements) {
            canvas.drawRect(el.bounds, boxPaint)

            val label = "[${el.index}]"
            val textWidth = labelTextPaint.measureText(label)
            val labelRect = RectF(
                el.bounds.left.toFloat(),
                el.bounds.top.toFloat() - 32f,
                el.bounds.left + textWidth + 8f,
                el.bounds.top.toFloat()
            )
            if (labelRect.top < 0) {
                labelRect.offset(0f, 32f)
            }
            canvas.drawRect(labelRect, labelBgPaint)
            canvas.drawText(label, labelRect.left + 4f, labelRect.bottom - 6f, labelTextPaint)
        }

        return annotated
    }

    fun buildElementListText(elements: List<UiElement>): String {
        if (elements.isEmpty()) return ""
        return buildString {
            appendLine("Detected UI elements on screen:")
            for (el in elements) {
                val type = el.className.substringAfterLast(".")
                val text = when {
                    el.text.isNotBlank() -> "\"${el.text}\""
                    el.contentDescription.isNotBlank() -> "desc:\"${el.contentDescription}\""
                    else -> "(no text)"
                }
                val center = "${(el.bounds.left + el.bounds.right) / 2}, ${(el.bounds.top + el.bounds.bottom) / 2}"
                val flags = buildList {
                    if (el.isClickable) add("clickable")
                    if (el.isScrollable) add("scrollable")
                }.joinToString(",")
                appendLine("[${el.index}] $type $text at center($center) bounds(${el.bounds}) $flags")
            }
        }
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo,
        elements: MutableList<UiElement>,
        index: () -> Int
    ) {
        val dominated = node.isClickable || node.isScrollable ||
                !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()

        if (dominated && node.isVisibleToUser) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (bounds.width() > 10 && bounds.height() > 10) {
                elements.add(UiElement(
                    index = index(),
                    text = node.text?.toString()?.take(50) ?: "",
                    className = node.className?.toString() ?: "",
                    bounds = bounds,
                    isClickable = node.isClickable,
                    isScrollable = node.isScrollable,
                    contentDescription = node.contentDescription?.toString()?.take(50) ?: "",
                    viewId = node.viewIdResourceName ?: "",
                    enabled = node.isEnabled,
                    password = node.isPassword,
                    checked = node.isChecked,
                    selected = node.isSelected
                ))
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try { traverseNode(child, elements, index) } finally { child.recycle() }
        }
    }
}
