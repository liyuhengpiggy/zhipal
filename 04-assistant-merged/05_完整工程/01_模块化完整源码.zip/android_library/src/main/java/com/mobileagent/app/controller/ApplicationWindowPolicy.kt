package com.mobileagent.app.controller

/** Window facts only; kept independent of Android for regression tests. */
object ApplicationWindowPolicy {
    data class Candidate(val id: Int, val type: Int, val active: Boolean, val focused: Boolean, val layer: Int)
    fun select(windows: List<Candidate>): Int? = windows.filter { it.type == 1 }
        .maxWithOrNull(compareBy<Candidate> { it.active }.thenBy { it.focused }.thenBy { it.layer })?.id
}
