package com.bagent.sample

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Displays results immediately without a background Activity launch or task switch. */
class FloatingPanelManager(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var reject: (() -> Unit)? = null

    fun show(title: String, message: String, onConfirm: (() -> Unit)? = null,
             onDismiss: () -> Unit = {}): Boolean {
        dismiss(false)
        if (!Settings.canDrawOverlays(context)) return false
        val density = context.resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFFFFFFFF.toInt()) }
            elevation = dp(12).toFloat()
        }
        layout.addView(TextView(context).apply {
            text = title; textSize = 18f; setTextColor(0xFF111111.toInt())
        })
        layout.addView(ScrollView(context).apply {
            addView(TextView(context).apply {
                text = message; textSize = 16f; setTextColor(0xFF333333.toInt())
                setPadding(0, dp(16), 0, dp(16))
            })
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        val buttons = LinearLayout(context).apply { gravity = Gravity.END }
        buttons.addView(Button(context).apply {
            text = if (onConfirm == null) "关闭" else "取消"
            setOnClickListener { dismiss(true) }
        })
        if (onConfirm != null) buttons.addView(Button(context).apply {
            text = "执行"
            setOnClickListener {
                isEnabled = false
                // Remove the intercepting window before any validation or gesture.
                dismiss(false)
                onConfirm()
            }
        })
        layout.addView(buttons)
        val metrics = context.resources.displayMetrics
        val params = WindowManager.LayoutParams(
            (metrics.widthPixels * 0.88).toInt(), minOf(dp(300), (metrics.heightPixels * 0.6).toInt()),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        return try {
            wm.addView(layout, params)
            root = layout
            reject = onDismiss
            true
        } catch (_: Exception) { false }
    }

    fun dismiss(notify: Boolean = false) {
        val callback = reject
        reject = null
        val view = root
        root = null
        if (view != null) runCatching { wm.removeViewImmediate(view) }
        if (notify) callback?.invoke()
    }
}
