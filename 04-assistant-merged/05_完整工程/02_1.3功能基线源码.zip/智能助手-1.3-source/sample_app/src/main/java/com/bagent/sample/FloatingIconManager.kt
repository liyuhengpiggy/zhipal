package com.bagent.sample

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ViewConfiguration
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * 悬浮小图标：常驻屏幕一角，提示 B 助手正在后台运行。
 * 单击拖动，双击/长按关闭。可随时通过关闭按钮移除。
 */
class FloatingIconManager(private val context: Context) {
    private var windowManager: WindowManager? = null
    private var root: View? = null
    private var label: TextView? = null
    private var onClose: (() -> Unit)? = null
    private var onTap: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private val longPress = Runnable { close() }

    private val isOverlayGranted: Boolean
        get() = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                android.provider.Settings.canDrawOverlays(context)

    @SuppressLint("ClickableViewAccessibility")
    fun show(onClose: () -> Unit, onTap: () -> Unit) {
        if (!isOverlayGranted || root != null) return
        this.onClose = onClose
        this.onTap = onTap
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val density = context.resources.displayMetrics.density
        val size = (44 * density).toInt()

        // 圆形图标背景 + 提示文字
        val bubble = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE60088FF.toInt())
            }
            background = bg
        }
        val icon = TextView(context).apply {
            text = "B"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        label = icon
        bubble.addView(icon)

        val lp = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * density).toInt()
            y = (120 * density).toInt()
        }

        // 拖动
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y; moved = false
                    handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX; val dy = event.rawY - downY
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    val metrics = context.resources.displayMetrics
                    lp.x = (startX + dx.toInt()).coerceIn(0, (metrics.widthPixels - size).coerceAtLeast(0))
                    lp.y = (startY + dy.toInt()).coerceIn(0, (metrics.heightPixels - size).coerceAtLeast(0))
                    runCatching { wm.updateViewLayout(bubble, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!moved && root === bubble) {
                        // 单击：触发预测下一步
                        onTap?.invoke()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    true
                }
                else -> false
            }
        }
        // 长按关闭
        bubble.setOnLongClickListener {
            close()
            true
        }

        try {
            wm.addView(bubble, lp)
            root = bubble
        } catch (e: Exception) {
            root = null
            Toast.makeText(context, "悬浮图标启动失败，请检查悬浮窗权限", Toast.LENGTH_LONG).show()
            close()
        }
    }

    fun close() {
        handler.removeCallbacks(longPress)
        val callback = onClose
        onClose = null
        onTap = null
        val wm = windowManager; val v = root
        if (wm != null && v != null) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        root = null
        label = null
        windowManager = null
        callback?.invoke()
    }

    fun isShowing() = root != null
    fun setHidden(hidden: Boolean) { root?.visibility = if (hidden) View.INVISIBLE else View.VISIBLE }
    fun setStatus(text: String) {
        label?.text = text
        root?.contentDescription = when (text) {
            "…" -> "智能助手正在预测"
            "!" -> "智能助手预测结果待确认"
            "✓" -> "智能助手正在执行"
            else -> "智能助手悬浮按钮"
        }
    }
}
