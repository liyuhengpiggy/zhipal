package com.bagent.sample

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.bagent.android.AndroidAssistPort
import com.bagent.integration.Observation
import com.bagent.integration.RecentEvent
import com.bagent.integration.Suggestion
import com.mobileagent.app.api.ApiConfig
import com.mobileagent.app.api.OpenAiCompatibleClient
import com.mobileagent.app.api.VlmApiClient
import com.mobileagent.app.controller.ScreenCaptureManager
import com.mobileagent.app.controller.AppWindowResolver
import kotlinx.coroutines.*

/**
 * B 助手无障碍服务：
 * 1. 前台服务常驻后台（通知栏小图标）。
 * 2. 悬浮小图标提示运行中，可拖动、可长按关闭。
 * 3. 点击悬浮图标 -> 预测下一步操作 -> 弹窗确认 -> 执行一步。
 */
class SampleAccessService : AccessibilityService() {
    companion object {
        var instance: SampleAccessService? = null
            private set
        const val CHANNEL_ID = "b_assist_channel"
        const val NOTIFICATION_ID = 1001

        // 硬编码 SiliconFlow 配置
        const val API_ENDPOINT = "https://api.siliconflow.cn/v1"
        const val API_MODEL = "Qwen/Qwen3-VL-32B-Instruct"
        const val API_KEY = "sk-ylzzbvtwrcdduqlpqbjbbetuihukdprnuacokuasdbshojts"

        private const val PREDICT_GOAL = "根据用户最近的操作历史和当前屏幕内容，预测用户最可能想执行的下一步操作。"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val config = ApiConfig(
        provider = "openai",
        endpoint = API_ENDPOINT,
        apiKey = API_KEY,
        model = API_MODEL,
        coordType = "absolute",
        maxSteps = 1,
        maxOutputTokens = 96,
        temperature = 0.1,
        imageLongSide = 1152,
        jpegQuality = 78,
        requestTimeoutSeconds = 40
    )
    private val apiClient = OpenAiCompatibleClient(config)
    private val port: AndroidAssistPort by lazy { AndroidAssistPort(this, ::screenshot, apiClient, scope) }
    private var screenCapture: ScreenCaptureManager? = null

    private var pendingSuggestion: Suggestion? = null
    private var pendingScreen: Observation? = null
    private var predicting = false
    private var executing = false
    private var predictionJob: Job? = null
    private var executionJob: Job? = null
    private var expiryJob: Job? = null
    private var pendingAtMs = 0L
    private var requestId = 0L

    // 近期事件历史（供预测使用）
    private val recentEvents = ArrayDeque<RecentEvent>()

    override fun onServiceConnected() {
        instance = this
        getSharedPreferences("access_status", Context.MODE_PRIVATE).edit().putBoolean("was_connected", true).apply()
        startForegroundService(false)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() == packageName || predicting || executing || pendingScreen != null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> recordClick(event)
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> recordPage(event)
        }
    }

    private fun recordClick(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        val source = event.source
        val control = try { source?.let { "${event.packageName}|${it.viewIdResourceName}|${it.text}|${it.contentDescription}" }.orEmpty() } finally { source?.recycle() }
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.CLICK, page, control))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    private fun recordPage(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.PAGE, page))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    private fun recordOther(event: AccessibilityEvent) {
        val page = runCatching { port.pageSignature() }.getOrNull() ?: return
        recentEvents.addLast(RecentEvent(SystemClock.elapsedRealtime(), RecentEvent.Kind.OTHER, page))
        while (recentEvents.size > 16) recentEvents.removeFirst()
    }

    /**
     * 悬浮图标触发：截图 -> 模型预测下一步 -> 弹窗确认。
     */
    fun predictNextStep() {
        if (predicting || executing || pendingScreen != null) {
            restoreFloatingUi()
            return
        }
        FloatingService.instance?.dismissPanel()
        predicting = true
        val id = ++requestId
        predictionJob = scope.launch {
            var screen: Observation? = null
            val started = SystemClock.elapsedRealtime()
            var captureMs = 0L
            var modelStarted = false
            var outcome = "已取消"
            try {
                if (!hasScreenCapture()) {
                    showErrorDialog("屏幕截图尚未初始化！\n\n请先打开「智能助手」App，点击第 2 步「授权屏幕截图（录屏）」，在系统弹窗里点「允许/开始」。\n\n授权后再点击悬浮图标。")
                    return@launch
                }
                FloatingService.instance?.setStatus("…")
                delay(150) // Let the bubble's touch interaction finish before selecting the app.
                val history = recentEvents.filter { SystemClock.elapsedRealtime() - it.atMs < 120_000 }
                val targetPackage = withTimeoutOrNull(1_500) {
                    var name = activePackage()
                    while (name == null) { delay(100); name = activePackage() }
                    name
                }
                if (targetPackage == packageName) {
                    showErrorDialog("当前仍在智能助手设置页。请返回桌面，打开要操作的应用，再点蓝色悬浮按钮。")
                    return@launch
                }
                check(targetPackage != null) { "未能读取当前应用，请检查无障碍服务后重试" }
                val captureStarted = SystemClock.elapsedRealtime()
                val observed = port.observe()
                captureMs = SystemClock.elapsedRealtime() - captureStarted
                screen = observed
                modelStarted = true
                val suggestion = withTimeout(60_000) { port.suggest(PREDICT_GOAL, history, observed) }
                pendingAtMs = SystemClock.elapsedRealtime()
                pendingSuggestion = suggestion
                pendingScreen = screen
                screen = null // 所有权转交，确认或取消时释放
                expiryJob = scope.launch {
                    delay(60_001)
                    onUserRejectNextStep(id)
                }
                outcome = "已生成待确认结果"
                showConfirmDialog(suggestion.description, id)
            } catch (e: TimeoutCancellationException) {
                outcome = "预测超时"
                showErrorDialog("预测超时，请检查网络后重试")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                outcome = e.message ?: "预测失败"
                pendingSuggestion = null
                pendingScreen?.let { port.release(it) }
                pendingScreen = null
                showErrorDialog("预测失败：\n${e.message ?: "未知错误"}\n\n（请把这段文字发给开发者）")
            } finally {
                screen?.let { port.release(it) }
                FloatingService.instance?.setIconHidden(false)
                predicting = false
                val stats = if (modelStarted) apiClient.lastStats else null
                recordDiagnostic("预测：$outcome；总耗时=${SystemClock.elapsedRealtime()-started}ms；截图=${captureMs}ms；模型=${stats?.elapsedMs ?: 0}ms；请求=${stats?.attempts ?: 0}次；上传=${stats?.requestBytes ?: 0}字节；输出=${stats?.outputTokens ?: 0}tokens")
                updateFloatingStatus()
            }
        }
    }

    private fun showConfirmDialog(description: String, id: Long) {
        FloatingService.instance?.setIconHidden(false)
        FloatingService.instance?.setStatus("!")
        if (FloatingService.instance?.showConfirmation(description, id) == true) return
        val intent = Intent(this, ConfirmDialogActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.putExtra(ConfirmDialogActivity.EXTRA_DESCRIPTION, description)
        intent.putExtra(ConfirmDialogActivity.EXTRA_REQUEST_ID, id)
        try { startActivity(intent) } catch (e: Exception) {
            onUserRejectNextStep(id)
            showErrorDialog("无法显示确认窗口：${e.message}")
        }
    }

    private fun showErrorDialog(message: String) {
        if (FloatingService.instance?.showMessage(message) == true) return
        val intent = Intent(this, ErrorDialogActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.putExtra(ErrorDialogActivity.EXTRA_MESSAGE, message)
        try { startActivity(intent) } catch (_: Exception) {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** 用户点了"执行"。 */
    fun onUserConfirmNextStep(id: Long) {
        if (id != requestId || executing) return
        val suggestion = pendingSuggestion
        val screen = pendingScreen
        pendingSuggestion = null
        pendingScreen = null
        expiryJob?.cancel()
        if (suggestion == null || screen == null) {
            android.widget.Toast.makeText(this, "确认已失效，请重新预测", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        executing = true
        FloatingService.instance?.dismissPanel()
        updateFloatingStatus()
        executionJob = scope.launch {
            val executionStarted = SystemClock.elapsedRealtime()
            var executionOutcome = "未执行"
            var dispatched = false
            var dispatchResult: Boolean? = null
            try {
                require(ConfirmationPolicy.isFresh(pendingAtMs, SystemClock.elapsedRealtime())) { "确认已过期，请重新预测" }
                // Overlay confirm has already been removed; Activity fallback waits for onStop.
                withTimeout(2_500) {
                    while (activePackage() != screen.packageName) delay(80)
                }
                delay(80)
                FloatingService.instance?.setIconHidden(true)
                try {
                    val completion = port.dispatchOnce(screen, suggestion)
                    dispatched = true
                    dispatchResult = withTimeoutOrNull(5_000) { completion.await() }
                    check(dispatchResult == true) { "操作未完成" }
                } finally { FloatingService.instance?.setIconHidden(false) }
                val changed = withTimeoutOrNull(1_000) {
                    while (port.pageSignature() == port.lastBeforeDispatchSignature) delay(150)
                    true
                } == true
                executionOutcome = if (changed) "系统已接受点击，页面内容有变化" else "系统已接受点击，但未检测到页面变化，请检查目标应用"
                android.widget.Toast.makeText(this@SampleAccessService, executionOutcome, android.widget.Toast.LENGTH_LONG).show()
            } catch (e: TimeoutCancellationException) {
                executionOutcome = "目标应用未恢复"
                showErrorDialog("目标应用未恢复，已取消执行，请切换到目标应用后重新预测")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                executionOutcome = e.message ?: "执行失败"
                if (dispatched) {
                    val message = if (dispatchResult == false) "点击被系统拒绝或取消，请重试" else "已提交点击，结果未知，请检查目标应用"
                    android.widget.Toast.makeText(this@SampleAccessService, message, android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    showErrorDialog("执行失败：\n${e.message ?: "未知错误"}\n\n（请把这段文字发给开发者）")
                }
            } finally {
                recordDiagnostic("执行：$executionOutcome；耗时=${SystemClock.elapsedRealtime()-executionStarted}ms；方式=${port.lastDispatchMode}")
                port.release(screen)
                FloatingService.instance?.setIconHidden(false)
                executing = false
                updateFloatingStatus()
            }
        }
    }

    /** 用户点了"取消"。 */
    fun onUserRejectNextStep(id: Long = requestId) {
        if (id != requestId) return
        expiryJob?.cancel()
        val screen = pendingScreen
        pendingSuggestion = null
        pendingScreen = null
        screen?.let { port.release(it) }
        FloatingService.instance?.dismissPanel()
        updateFloatingStatus()
    }

    private fun recordDiagnostic(message: String) {
        val prefs = getSharedPreferences("diagnostics", Context.MODE_PRIVATE)
        val previous = prefs.getString("recent", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(11)
        prefs.edit().putString("recent", (previous + message).joinToString("\n")).apply()
    }

    private fun updateFloatingStatus() {
        FloatingService.instance?.setStatus(when {
            executing -> "✓"
            pendingSuggestion != null -> "!"
            predicting -> "…"
            else -> "B"
        })
    }

    fun restoreFloatingUi() {
        updateFloatingStatus()
        val suggestion = pendingSuggestion ?: return
        if (ConfirmationPolicy.isFresh(pendingAtMs, SystemClock.elapsedRealtime())) {
            showConfirmDialog(suggestion.description, requestId)
        } else onUserRejectNextStep()
    }

    private fun activePackage(): String? {
        val node = AppWindowResolver.obtainRoot(this) ?: return null
        return try { node.packageName?.toString() } finally { node.recycle() }
    }

    /** Called only after the visible Activity receives projection consent. */
    fun initScreenCapture(resultCode: Int, data: Intent): Boolean {
        screenCapture?.release()
        screenCapture = null
        val capture = ScreenCaptureManager(this)
        return try {
            startForegroundService(true)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            capture.initialize(manager.getMediaProjection(resultCode, data))
            screenCapture = capture
            true
        } catch (e: Exception) {
            capture.release()
            startForegroundService(false)
            android.widget.Toast.makeText(this, "截图初始化失败：${e.message}", android.widget.Toast.LENGTH_LONG).show()
            false
        }
    }

    private suspend fun screenshot(): Bitmap? {
        val capture = screenCapture ?: return null
        FloatingService.instance?.setIconHidden(true)
        return try {
            delay(120) // Hide only for this capture, not while the model is thinking.
            capture.capture()
        } finally { FloatingService.instance?.setIconHidden(false) }
    }

    /** 供 MainActivity 查询截图是否已就绪。 */
    fun hasScreenCapture(): Boolean = screenCapture?.isReady == true

    private fun startForegroundService(capturing: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "智能助手后台服务", NotificationManager.IMPORTANCE_LOW))
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)
        val built = notification
            .setContentTitle("智能助手正在运行")
            .setContentText("点击悬浮图标预测下一步操作")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                (if (capturing) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
            startForeground(NOTIFICATION_ID, built, type)
        } else {
            startForeground(NOTIFICATION_ID, built)
        }
    }

    override fun onInterrupt() {
        predictionJob?.cancel()
        executionJob?.cancel()
        onUserRejectNextStep()
    }

    override fun onDestroy() {
        onInterrupt()
        screenCapture?.release()
        screenCapture = null
        scope.cancel()
        instance = null
        super.onDestroy()
    }
}
