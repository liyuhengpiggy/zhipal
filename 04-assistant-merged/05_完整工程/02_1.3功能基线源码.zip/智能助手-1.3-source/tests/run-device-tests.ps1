param([string]$Gradle = "", [string]$Serial = "")
$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
if (!$env:ANDROID_HOME) { throw "Set ANDROID_HOME to the Android SDK path" }
$adb = Join-Path $env:ANDROID_HOME "platform-tools/adb.exe"
if (!(Test-Path -LiteralPath $adb)) { throw "adb.exe not found" }
$deviceArgs = @()
if ($Serial) { $deviceArgs = @("-s", $Serial) }
& $adb @deviceArgs get-state
if ($LASTEXITCODE) { throw "Connect and authorize exactly one device, or specify -Serial" }
Push-Location $projectRoot
try {
    if (!$Gradle) { $Gradle = Join-Path $projectRoot "gradlew.bat" }
    & $Gradle :integration:test :android_library:testDebugUnitTest :sample_app:testDebugUnitTest :sample_app:assembleDebug :sample_app:assembleDebugAndroidTest --console=plain
    if ($LASTEXITCODE) { throw "Build failed" }
    & $adb @deviceArgs install -r (Join-Path $projectRoot "sample_app/build/outputs/apk/debug/sample_app-debug.apk")
    if ($LASTEXITCODE) { throw "APK install failed" }
    & $adb @deviceArgs install -r (Join-Path $projectRoot "sample_app/build/outputs/apk/androidTest/debug/sample_app-debug-androidTest.apk")
    if ($LASTEXITCODE) { throw "Test APK install failed" }
    $result = & $adb @deviceArgs shell am instrument -w -r -e class com.bagent.sample.DeviceAcceptanceTest com.bagent.sample.test/androidx.test.runner.AndroidJUnitRunner 2>&1
    $result | Set-Content -LiteralPath (Join-Path $PSScriptRoot "last-device-run.log") -Encoding UTF8
    $result
    if (($result -join "`n") -notmatch 'OK \(4 tests\)') { throw "Smoke tests failed; inspect last-device-run.log" }
} finally { Pop-Location }
