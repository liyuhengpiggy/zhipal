plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.serialization") }
android {
 namespace = "com.bagent.library"
 compileSdk = 34
 defaultConfig { minSdk = 26; consumerProguardFiles("consumer-rules.pro") }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 testImplementation("junit:junit:4.13.2")
 api(project(":integration"))
 api("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
 implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
}

// Copies the exact resolved runtime artifacts for binary handoff (no secret/config data).
tasks.register<Copy>("exportHandoffDependencies") {
    dependsOn(":integration:jar")
    from(configurations.named("releaseRuntimeClasspath"))
    into(rootProject.layout.projectDirectory.dir("artifacts/runtime-dependencies"))
}
